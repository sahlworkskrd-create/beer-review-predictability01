# JRCS FINAL FIGURE GENERATION — reconstruction from deposited analytical files
# Plotting script assembled 2026-09-18. NOT the original complete analysis pipeline.
# Place this script alongside the input CSVs listed below, then Source in RStudio.
# It NEVER substitutes simulated predictions or hard-coded results for missing inputs.
required <- c('ggplot2','dplyr','tidyr','ggrepel')
missing <- required[!vapply(required,requireNamespace,logical(1),quietly=TRUE)]
if(length(missing)) stop('Install packages first: install.packages(c(',paste(sprintf('"%s"',missing),collapse=','),'))')
library(ggplot2);library(dplyr);library(tidyr)
input_dir <- getwd() # setwd('C:/path/to/folder') BEFORE sourcing, if needed
output_dir <- file.path(input_dir,'JRCS_Final_Figures');dir.create(output_dir,showWarnings=FALSE)
read_required <- function(name) {p<-file.path(input_dir,name);if(!file.exists(p))stop('Missing input: ',p);read.csv(p,check.names=FALSE,stringsAsFactors=FALSE)}
export <- function(p,name,w=8,h=5.5){ggsave(file.path(output_dir,paste0(name,'.tiff')),p,width=w,height=h,units='in',dpi=600,compression='lzw',limitsize=FALSE);ggsave(file.path(output_dir,paste0(name,'.pdf')),p,width=w,height=h,units='in',limitsize=FALSE)}
th <- theme_minimal(base_size=12)+theme(panel.grid.minor=element_blank(),legend.position='bottom',axis.text=element_text(color='black'),strip.text=element_text(face='bold'))
vars <- c('review_aroma','review_appearance','review_palate','review_taste')
labels <- c('Aroma','Appearance','Palate','Taste')
sample <- read_required('Analytical_Sample_5456.csv')
stopifnot(nrow(sample)==5456L,all(vars %in% names(sample)))
X <- as.data.frame(lapply(sample[vars],as.numeric));stopifnot(all(complete.cases(X)))
# Figure 1: exact sample correlations (not a copy of pre-rendered artwork)
C <- cor(X);dimnames(C)<-list(labels,labels)
heat <- as.data.frame(as.table(C));names(heat)<-c('Row','Column','Correlation')
p1 <- ggplot(heat,aes(Column,Row,fill=Correlation))+geom_tile(color='white')+geom_text(aes(label=sprintf('%.3f',Correlation)),size=4)+coord_equal()+scale_fill_gradient2(low='#2166AC',mid='white',high='#B2182B',midpoint=0,limits=c(-1,1))+labs(x=NULL,y=NULL,fill='Pearson r')+th
export(p1,'Figure1_Correlation_Heatmap',7,6)
# Figures 2–3: PCA is RECOMPUTED from the supplied analytical sample.
# Confirm preprocessing against original PCA code before claiming exact replication.
pca <- prcomp(X,center=TRUE,scale.=TRUE)
ve <- 100*pca$sdev^2/sum(pca$sdev^2)
p2 <- ggplot(data.frame(PC=factor(paste0('PC',seq_along(ve)),levels=paste0('PC',seq_along(ve))),Variance=ve),aes(PC,Variance))+geom_col(fill='#377D9F',width=.65)+geom_text(aes(label=sprintf('%.2f%%',Variance)),vjust=-.3)+expand_limits(y=max(ve)*1.12)+labs(x='Principal component',y='Variance explained (%)')+th
export(p2,'Figure2_Scree_Plot',7,5)
scores <- as.data.frame(pca$x);load <- as.data.frame(pca$rotation);load$Attribute<-labels
mult <- .75*min(diff(range(scores$PC1))/max(abs(load$PC1)),diff(range(scores$PC2))/max(abs(load$PC2)))
p3 <- ggplot(scores,aes(PC1,PC2))+geom_point(alpha=.20,size=.6,color='#377D9F')+geom_segment(data=load,aes(x=0,y=0,xend=PC1*mult,yend=PC2*mult),inherit.aes=FALSE,arrow=grid::arrow(length=grid::unit(.17,'cm')),color='#B44A38',linewidth=.7)+ggrepel::geom_text_repel(data=load,aes(x=PC1*mult,y=PC2*mult,label=Attribute),inherit.aes=FALSE,fontface='bold')+labs(x=sprintf('PC1 (%.2f%%)',ve[1]),y=sprintf('PC2 (%.2f%%)',ve[2]))+th
export(p3,'Figure3_PCA_Biplot_PC1_PC2',8,6)
# Figure 4: cluster memberships were not supplied; recreate k=2 by kmeans on
# standardized sensory ratings and check sizes against manuscript before using.
set.seed(123);km <- kmeans(scale(X),centers=2,nstart=50)
means <- aggregate(X,list(cluster=km$cluster),mean)
ord <- order(means$review_taste,decreasing=TRUE)
new_id <- match(km$cluster,ord)
counts <- as.integer(table(factor(new_id,levels=1:2)))
if(!identical(counts,c(3956L,1500L))) warning('RECONSTRUCTED CLUSTER COUNTS DIFFER: ',paste(counts,collapse=', '),'. Do not replace final Figure 4 without original cluster labels/settings.')
cluster_scores <- data.frame(PC1=scores$PC1,PC2=scores$PC2,Cluster=factor(new_id))
p4 <- ggplot(cluster_scores,aes(PC1,PC2,color=Cluster))+geom_point(alpha=.42,size=.75)+labs(x=sprintf('PC1 (%.2f%%)',ve[1]),y=sprintf('PC2 (%.2f%%)',ve[2]),subtitle=paste('Reconstructed cluster sizes:',paste(counts,collapse=' / ')))+th
export(p4,'Figure4_Cluster_Projection_RECONSTRUCTED',8,6)
# Figures 5–6: use SAVED ORIGINAL review-level predictions, not fitted approximations.
pred <- read_required('Predictions_Review_level.csv');stopifnot(all(c('Observed_Taste','SVR')%in%names(pred)))
pred$Residual <- pred$Observed_Taste-pred$SVR
p5 <- ggplot(pred,aes(Observed_Taste,SVR))+geom_point(alpha=.4,size=1,color='#377D9F')+geom_abline(slope=1,intercept=0,linetype='dashed')+coord_equal()+labs(x='Observed taste',y='Predicted taste (SVR)')+th
export(p5,'Figure5_SVR_Observed_vs_Predicted',7,6)
p6 <- ggplot(pred,aes(SVR,Residual))+geom_point(alpha=.4,size=1,color='#377D9F')+geom_hline(yintercept=0,linetype='dashed')+labs(x='Predicted taste (SVR)',y='Residual (observed - predicted)')+th
export(p6,'Figure6_SVR_Residual_Diagnostics',7,6)
# Figure 7: original exported RF permutation-importance values.
imp <- read_required('Table8_RF_Permutation_Importance.csv')
stopifnot(all(c('Feature_Label','Permutation_Importance')%in%names(imp)))
p7 <- ggplot(imp,aes(reorder(Feature_Label,Permutation_Importance),Permutation_Importance))+geom_col(fill='#377D9F',width=.65)+coord_flip()+labs(x=NULL,y='Permutation importance')+th
export(p7,'Figure7_RF_Permutation_Importance',8,5)
# Figure 8: source CSV contains three replications; SD is descriptive, not CI.
sens <- read_required('Sensitivity_All_Runs.csv')
stopifnot(all(c('Seed','Sample_N','Regime','Model','RMSE')%in%names(sens)))
ss <- sens %>% group_by(Sample_N,Regime,Model) %>% summarise(Mean_RMSE=mean(RMSE),SD_RMSE=sd(RMSE),Replications=n(),.groups='drop')
stopifnot(all(ss$Replications==3L))
ss$Model <- factor(ss$Model,levels=c('Full','Reduced'),labels=c('Full RF (four predictors)','Reduced RF (palate + aroma)'))
p8 <- ggplot(ss,aes(Sample_N,Mean_RMSE,color=Model,shape=Model,group=Model))+geom_line(linewidth=.65)+geom_point(size=2.5)+geom_errorbar(aes(ymin=Mean_RMSE-SD_RMSE,ymax=Mean_RMSE+SD_RMSE),width=750,linewidth=.5)+facet_wrap(~Regime,scales='free_y')+scale_x_continuous(breaks=c(5456,20000,50000),labels=c('5,456','20,000','50,000'))+labs(x='Sample size (reviews)',y='Mean RMSE',color=NULL,shape=NULL)+th
export(p8,'Figure8_Sample_Size_Sensitivity',11,5)
# Supplementary Figure S1: PC1–PC3 projection; this PCA is reconstructed.
pS1 <- ggplot(scores,aes(PC1,PC3))+geom_point(alpha=.2,size=.6,color='#377D9F')+geom_segment(data=load,aes(x=0,y=0,xend=PC1*mult,yend=PC3*mult),inherit.aes=FALSE,arrow=grid::arrow(length=grid::unit(.17,'cm')),color='#B44A38')+ggrepel::geom_text_repel(data=load,aes(x=PC1*mult,y=PC3*mult,label=Attribute),inherit.aes=FALSE)+labs(x=sprintf('PC1 (%.2f%%)',ve[1]),y=sprintf('PC3 (%.2f%%)',ve[3]))+th
export(pS1,'FigureS1_PCA_PC1_PC3_RECONSTRUCTED',8,6)
# Supplementary Figure S2: actual individual seed-level RMSE from saved results.
sens$Model <- factor(sens$Model,levels=c('Full','Reduced'),labels=c('Full RF (four predictors)','Reduced RF (palate + aroma)'))
sens$Seed <- factor(sens$Seed)
pS2 <- ggplot(sens,aes(Sample_N,RMSE,color=Model,shape=Model,linetype=Seed,group=interaction(Model,Seed)))+geom_line(linewidth=.65)+geom_point(size=2)+facet_wrap(~Regime,scales='free_y')+scale_x_continuous(breaks=c(5456,20000,50000),labels=c('5,456','20,000','50,000'))+labs(x='Sample size (reviews)',y='RMSE',color=NULL,shape=NULL,linetype='Seed')+th
export(pS2,'FigureS2_Individual_Replications',11,5)
write.csv(ss,file.path(output_dir,'Figure8_Recomputed_Summary.csv'),row.names=FALSE)
writeLines(c('Figures 1,2,3,5,6,7,8,S2 are plotted from supplied sample/results.','Figures 2,3,S1: PCA recomputed using centered/scaled sensory variables; verify against original settings.','Figure 4: cluster labels reconstructed using kmeans(seed=123,nstart=50); verify original assignments and counts before use.','Figures 5/6 use SAVED review-level SVR predictions, not newly trained models.','No full model-training reproduction is claimed.',capture.output(sessionInfo())),file.path(output_dir,'FIGURE_PROVENANCE.txt'))
message('Finished. Figures in: ',output_dir)
