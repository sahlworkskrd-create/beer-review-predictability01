JRCS GROUPED NESTED FEATURE-VALIDATION EXPERIMENT

Date: 2026-09-16
Input file: C:\Users\sahlw\OneDrive\Desktop\YNU2\PROJECT\BEER REVIEW PREDICTION\DATASET\JRCS_Grouped_Validation_Results\Analytical_Sample_5456.csv
Analytical observations: 5456
Unique beers: 2897
Unique reviewers: 2907

VALIDATION DESIGN
Beer-disjoint and reviewer-disjoint analyses.
Five outer folds and three inner folds.
Group identifiers exclusive across train/test folds.
Inner model selection uses pooled out-of-fold RMSE.
Outer folds used only for performance evaluation.

CANDIDATE SPECIFICATIONS
Full: aroma, appearance, palate, ABV.
Reduced: palate, aroma.

RANDOM FOREST SETTINGS
Trees: 500.
mtry: 1.
Minimum node size: 10.
Split rule: variance.
Importance: none (not required for this experiment).
RF seed: 123.
RF threads: 1.

FOLD GENERATION
Outer fold seed: 123.
Inner fold seed: 456 + outer fold number.
Groups assigned using a reproducible greedy
observation-balancing procedure.

PREPROCESSING
Predictor medians calculated from training data only.
No test-fold outcome information used for model selection.

INTERPRETATION
This is additional internal validation.
The reduced predictor set was identified in a previous
exploratory analysis using the original review-level test set.
Consequently, these results are not independent external
confirmation of the reduced specification.
The five outer folds are different from the original
80/20 grouped holdout partitions; metrics should not
be described as direct reproductions of Table 6.

SOFTWARE
R version 4.5.1 (2025-06-13 ucrt)
Platform: x86_64-w64-mingw32/x64
Running under: Windows 11 x64 (build 26200)

Matrix products: default
  LAPACK version 3.12.1

locale:
[1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8   
[3] LC_MONETARY=English_United Kingdom.utf8 LC_NUMERIC=C                           
[5] LC_TIME=English_United Kingdom.utf8    

time zone: Africa/Lagos
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] readr_2.1.5   ggplot2_4.0.3 ranger_0.18.0 dplyr_1.2.1  

loaded via a namespace (and not attached):
 [1] tidyselect_1.2.1     timeDate_4051.111    farver_2.1.2         S7_0.2.0            
 [5] pROC_1.19.0.1        caret_7.0-1          digest_0.6.37        rpart_4.1.24        
 [9] timechange_0.3.0     lifecycle_1.0.5      survival_3.8-3       magrittr_2.0.4      
[13] compiler_4.5.1       rlang_1.3.0          tools_4.5.1          data.table_1.17.8   
[17] labeling_0.4.3       bit_4.6.0            xgboost_1.7.11.1     bench_1.1.4         
[21] plyr_1.8.9           RColorBrewer_1.1-3   withr_3.0.2          purrr_1.1.0         
[25] nnet_7.3-20          grid_4.5.1           stats4_4.5.1         future_1.67.0       
[29] globals_0.18.0       scales_1.4.0         iterators_1.0.14     MASS_7.3-65         
[33] dichromat_2.0-0.1    cli_3.6.5            crayon_1.5.3         ragg_1.5.0          
[37] generics_0.1.4       rstudioapi_0.17.1    peakRAM_1.0.2        future.apply_1.20.0 
[41] reshape2_1.4.4       tzdb_0.5.0           readxl_1.5.0         stringr_1.5.2       
[45] splines_4.5.1        parallel_4.5.1       cellranger_1.1.0     vctrs_0.7.3         
[49] hardhat_1.4.2        Matrix_1.7-3         jsonlite_2.0.0       hms_1.1.4           
[53] bit64_4.6.0-1        listenv_0.9.1        systemfonts_1.3.1    foreach_1.5.2       
[57] gower_1.0.2          tidyr_1.3.2          recipes_1.3.1        glue_1.8.0          
[61] parallelly_1.45.1    codetools_0.2-20     lubridate_1.9.4      stringi_1.8.7       
[65] gtable_0.3.6         tibble_3.3.0         pillar_1.11.1        ipred_0.9-15        
[69] randomForest_4.7-1.2 lava_1.8.2           gbm_2.2.2            R6_2.6.1            
[73] textshaping_1.0.4    vroom_1.6.6          lattice_0.22-7       tidygeocoder_1.0.6  
[77] class_7.3-23         Rcpp_1.1.0           nlme_3.1-168         prodlim_2025.04.28  
[81] mgcv_1.9-3           ModelMetrics_1.2.2.2 pkgconfig_2.0.3     
