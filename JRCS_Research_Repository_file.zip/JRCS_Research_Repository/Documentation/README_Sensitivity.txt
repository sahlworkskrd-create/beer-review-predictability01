Sample-size sensitivity of full vs palate-aroma Random Forest; NOT original Table 6 replication.
Input: C:\Users\sahlw\OneDrive\Desktop\YNU2\PROJECT\BEER REVIEW PREDICTION\DATASET\beer_reviews.xlsx
Original eligible 1,048,340; excluded seven zero-appearance records; corrected eligible 1,048,333.
Eligibility: complete sensory scores within 1-5; nonblank beer and reviewer IDs; ABV may be missing.
Simple random subsamples without replacement for each seed and size; subsets across seeds and sizes may overlap.
Three seeds: 123, 456, 789; sample sizes: 5,456, 20,000, 50,000.
Group-disjoint approximately 80/20 train/test partitions; training-only ABV median imputation.
RF: ranger 500 trees, mtry 1, minimum node 10, variance split, seed 123, single thread.
No tuning on test data; the reduced model was previously chosen exploratorily; no external validation.
Across-seed summaries are descriptive, not confidence intervals; sample sizes and splits differ from definitive Table 6.
R version 4.5.1 (2025-06-13 ucrt)
Platform: x86_64-w64-mingw32/x64
Running under: Windows 11 x64 (build 26200)

Matrix products: default
  LAPACK version 3.12.1

locale:
[1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8   
[3] LC_MONETARY=English_United Kingdom.utf8 LC_NUMERIC=C                           
[5] LC_TIME=English_United Kingdom.utf8    

time zone: Africa/Lagos
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
[1] ranger_0.18.0 readxl_1.5.0 

loaded via a namespace (and not attached):
 [1] gbm_2.2.2            gtable_0.3.6         ggplot2_4.0.3        recipes_1.3.1       
 [5] bench_1.1.4          lattice_0.22-7       tzdb_0.5.0           vctrs_0.7.3         
 [9] tools_4.5.1          generics_0.1.4       stats4_4.5.1         parallel_4.5.1      
[13] tibble_3.3.0         ModelMetrics_1.2.2.2 pkgconfig_2.0.3      Matrix_1.7-3        
[17] data.table_1.17.8    RColorBrewer_1.1-3   S7_0.2.0             lifecycle_1.0.5     
[21] compiler_4.5.1       farver_2.1.2         stringr_1.5.2        codetools_0.2-20    
[25] class_7.3-23         prodlim_2025.04.28   pillar_1.11.1        tidyr_1.3.2         
[29] MASS_7.3-65          gower_1.0.2          iterators_1.0.14     rpart_4.1.24        
[33] foreach_1.5.2        nlme_3.1-168         parallelly_1.45.1    lava_1.8.2          
[37] tidyselect_1.2.1     digest_0.6.37        stringi_1.8.7        future_1.67.0       
[41] kernlab_0.9-33       tidygeocoder_1.0.6   dplyr_1.2.1          reshape2_1.4.4      
[45] purrr_1.1.0          listenv_0.9.1        splines_4.5.1        grid_4.5.1          
[49] cli_3.6.5            magrittr_2.0.4       randomForest_4.7-1.2 dichromat_2.0-0.1   
[53] survival_3.8-3       future.apply_1.20.0  withr_3.0.2          readr_2.1.5         
[57] scales_1.4.0         xgboost_1.7.11.1     lubridate_1.9.4      timechange_0.3.0    
[61] globals_0.18.0       nnet_7.3-20          timeDate_4051.111    cellranger_1.1.0    
[65] hms_1.1.4            hardhat_1.4.2        caret_7.0-1          rlang_1.3.0         
[69] Rcpp_1.1.0           glue_1.8.0           pROC_1.19.0.1        ipred_0.9-15        
[73] peakRAM_1.0.2        jsonlite_2.0.0       rstudioapi_0.17.1    R6_2.6.1            
[77] plyr_1.8.9          
