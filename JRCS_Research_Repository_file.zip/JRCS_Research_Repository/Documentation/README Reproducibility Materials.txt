# Reproducibility Materials

## Article

Consumer Sensory Rating Structure and Cross-Attribute Predictability: Evidence from Online Beer Reviews

Author: Siyanbola Hakeem Opeyemi

## Overview

This archive contains available research materials supporting the analysis of cross-attribute taste-score predictability in BeerAdvocate reviews.

The study includes an original model-comparison experiment, grouped nested cross-validation, exploratory predictor analysis, and sample-size sensitivity experiments.

## Data source

Original dataset: BeerAdvocate reviews, available through the UCSD Recommender Systems Dataset Repository.

Source URL: https://cseweb.ucsd.edu/~jmcauley/datasets.html

Exact source version: beer_reviews

## Analytical samples

Original analytical sample: 5,456 reviews.

Sensitivity analysis: The initial eligible population contained 1,048,340 reviews. Seven records with invalid appearance ratings were excluded, producing a corrected sampling frame of 1,048,333 reviews.

## Reproduction instructions

1. Obtain the original dataset from the stated source.
2. Apply the documented eligibility and preprocessing procedures.
3. Reconstruct the analytical sample using the original sampling procedure and identifiers, where available.
4. Execute the supplied analysis scripts in the order described in the relevant script headers.
5. Compare regenerated outputs with the supplied result tables.

## Sensitivity analysis

Sample sizes: 5,456; 20,000; 50,000.

Sampling seeds: 123, 456 and 789.

Validation: Beer-disjoint and reviewer-disjoint holdouts.

The supplied sensitivity outputs include model-run results, summary statistics, paired comparisons and partition-integrity checks.

## Software

R version: 4.5.1, as recorded in the supplied grouped-validation documentation.

Additional package versions: Package	Version
readxl	1.5.0
dplyr	1.2.1
caret	7.0.1
randomForest	4.7.1.2
e1071	1.7.16
ggplot2	4.0.3
tidyr	1.3.2
stringr	1.5.2
tibble	3.3.0
ranger	0.18.0
The corrected sample-size sensitivity analysis uses readxl and ranger. Other packages support the available data-processing, modeling and figure-generation workflows.

## Availability limitations

The repository contains the available analysis scripts, figure-generation materials, corrected sample-size sensitivity workflow, associated result files and reproducibility documentation.

The corrected sensitivity analysis covers three sample sizes (5,456, 20,000 and 50,000 reviews), three random seeds (123, 456 and 789), and beer-disjoint and reviewer-disjoint validation. Its exported outputs document model performance, paired comparisons and partition-integrity checks.

The exact original 5,456-review analytical sample, original train/test partition identifiers, complete executable scripts for the initial model-comparison experiment, and complete grouped nested-cross-validation implementation have not yet been verified as present in the archive.

Consequently, the repository supports inspection and partial reproduction of the reported analyses but should not be interpreted as providing independently verified, end-to-end reproduction of every experiment.

The original BeerAdvocate dataset is available from its external source repository. Any source-data redistribution restrictions and additional unavailable materials are documented here and should be considered when attempting to reproduce the study.

## Redistribution

The underlying BeerAdvocate reviews originate from a third-party dataset distributed through the UCSD Recommender Systems Dataset Repository:

https://cseweb.ucsd.edu/~jmcauley/datasets.html

The author does not claim ownership of the original BeerAdvocate dataset. Users should obtain the source data from the original provider and comply with the applicable terms of use, attribution requirements and redistribution restrictions.

Redistribution of the original review records or a derived analytical sample is subject to verification of the source dataset's applicable terms and consideration of any reviewer-identifying information.

The original R scripts and documentation developed by the author are separate from the third-party dataset. Their reuse and redistribution are governed by the license explicitly assigned to those materials in the published repository.

No license is claimed for the author's code until the applicable license has been selected and included in the repository.

## Contact

Siyanbola Hakeem Opeyemi

[hakeem.siyanbola@gmail.com](mailto:hakeem.siyanbola@gmail.com)
