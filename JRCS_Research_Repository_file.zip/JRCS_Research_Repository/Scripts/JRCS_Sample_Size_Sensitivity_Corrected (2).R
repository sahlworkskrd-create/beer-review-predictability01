# JRCS SAMPLE-SIZE SENSITIVITY — run in RStudio with Source
# This is a NEW sensitivity analysis; it does not reproduce the original Table 6 splits.
# Input: original BeerAdvocate .xlsx. Output: CSVs and reproducibility notes.
# Requires: readxl, ranger. Install automatically if missing.
for (pkg in c('readxl','ranger')) if (!requireNamespace(pkg, quietly=TRUE)) install.packages(pkg)
library(readxl); library(ranger)
set.seed(123)
path <- file.choose()
headers <- names(readxl::read_excel(path, n_max=0, .name_repair='minimal'))
required <- c('review_taste','review_aroma','review_appearance','review_palate','beer_abv','beer_beerid','review_profilename')
if (!all(required %in% headers)) stop('Required columns absent: ', paste(setdiff(required,headers),collapse=', '))
# Skip unnecessary columns to reduce memory pressure on the 1-million-row workbook.
ct <- ifelse(headers %in% required, 'text', 'skip')
cat('Reading seven necessary columns. This may take several minutes.\n')
d <- as.data.frame(readxl::read_excel(path, col_types=ct, .name_repair='minimal'))
for (v in c('review_taste','review_aroma','review_appearance','review_palate','beer_abv')) d[[v]] <- suppressWarnings(as.numeric(d[[v]]))
for (v in c('beer_beerid','review_profilename')) d[[v]] <- trimws(as.character(d[[v]]))
# Eligibility rule must match original workflow: observed taste, aroma, appearance, palate,
# and valid grouping IDs; missing ABV is retained for training-only median imputation.
valid_original <- is.finite(d$review_taste) & is.finite(d$review_aroma) & is.finite(d$review_appearance) & is.finite(d$review_palate) &
  !is.na(d$beer_beerid) & nzchar(d$beer_beerid) & !is.na(d$review_profilename) & nzchar(d$review_profilename)
valid_range <- rep(TRUE, nrow(d))
for (v in c('review_taste','review_aroma','review_appearance','review_palate'))
  valid_range <- valid_range & is.finite(d[[v]]) & d[[v]] >= 1 & d[[v]] <= 5
valid <- valid_original & valid_range
cat('Original eligible:', sum(valid_original), '; excluded out-of-range:', sum(valid_original & !valid_range),
    '; corrected eligible:', sum(valid), '\n')
stopifnot(sum(valid_original) == 1048340L,
          sum(valid_original & !valid_range) == 7L,
          sum(valid) == 1048333L)
d <- d[valid,,drop=FALSE]; rownames(d) <- NULL
stopifnot(nrow(d) == 1048333L)
# Sensitivity sizes and seeds; adjust MAX_SIZE only if resources are insufficient.
sizes <- c(5456L,20000L,50000L)
seeds <- c(123L,456L,789L)
if(max(sizes)>nrow(d)) stop('Insufficient eligible rows')
outdir <- file.path(dirname(path),paste0('JRCS_Sample_Size_Sensitivity_',format(Sys.time(),'%Y%m%d_%H%M%S')))
dir.create(outdir,showWarnings=FALSE)
features <- list(Full=c('review_aroma','review_appearance','review_palate','beer_abv'), Reduced=c('review_palate','review_aroma'))
# Randomize group order and greedily balance observations across 80/20 group partitions.
group_split <- function(ids,seed) {
  ids <- as.character(ids); g <- unique(ids); counts <- tabulate(match(ids,g),nbins=length(g))
  set.seed(seed); order_g <- sample(seq_along(g)); order_g <- order_g[order(-counts[order_g])]
  assignment <- rep(FALSE,length(g)); test_count <- 0L; target <- round(length(ids)*0.2)
  for (j in order_g) if (test_count < target) { assignment[j] <- TRUE; test_count <- test_count+counts[j] }
  is_test <- assignment[match(ids,g)]
  if(!any(is_test) || all(is_test) || length(intersect(unique(ids[is_test]),unique(ids[!is_test])))>0) stop('Invalid group split')
  is_test
}
fit_predict <- function(train,test,predictors) {
  tr <- train[,c('review_taste',predictors),drop=FALSE]; te <- test[,predictors,drop=FALSE]
  for(v in predictors) {
    med <- median(tr[[v]][is.finite(tr[[v]])]); if(!is.finite(med)) stop('Missing training predictor: ',v)
    tr[[v]][!is.finite(tr[[v]])] <- med; te[[v]][!is.finite(te[[v]])] <- med
  }
  rf <- ranger::ranger(reformulate(predictors,response='review_taste'),data=tr,num.trees=500,mtry=1,min.node.size=10,
                       splitrule='variance',seed=123,num.threads=1,importance='none')
  as.numeric(predict(rf,data=te)$predictions)
}
metric <- function(y,p) {
  c(MAE=mean(abs(y-p)),RMSE=sqrt(mean((y-p)^2)),R2=1-sum((y-p)^2)/sum((y-mean(y))^2))
}
results <- list(); partitions <- list(); idx <- 0L
for(seed in seeds) for(n in sizes) {
  set.seed(seed); sub <- d[sample.int(nrow(d),n),,drop=FALSE]
  for(regime in c('Beer-disjoint','Reviewer-disjoint')) {
    grp <- if(regime=='Beer-disjoint') 'beer_beerid' else 'review_profilename'
    is_test <- group_split(sub[[grp]],seed+1000L)
    tr <- sub[!is_test,,drop=FALSE]; te <- sub[is_test,,drop=FALSE]
    partitions[[length(partitions)+1L]] <- data.frame(Seed=seed,Sample_N=n,Regime=regime,Train_N=nrow(tr),Test_N=nrow(te),
       Train_Groups=length(unique(tr[[grp]])),Test_Groups=length(unique(te[[grp]])),Group_Overlap=length(intersect(unique(tr[[grp]]),unique(te[[grp]]))))
    for(model in names(features)) {
      cat('Running:',seed,n,regime,model,'\n'); flush.console()
      p <- fit_predict(tr,te,features[[model]]); m <- metric(te$review_taste,p)
      idx <- idx+1L
      results[[idx]] <- data.frame(Seed=seed,Sample_N=n,Regime=regime,Model=model,Train_N=nrow(tr),Test_N=nrow(te),
                                   MAE=unname(m['MAE']),RMSE=unname(m['RMSE']),R2=unname(m['R2']))
      write.csv(do.call(rbind,results),file.path(outdir,'Sensitivity_All_Runs.csv'),row.names=FALSE)
    }
  }
}
res <- do.call(rbind,results); parts <- do.call(rbind,partitions)
write.csv(parts,file.path(outdir,'Sensitivity_Partition_Checks.csv'),row.names=FALSE)
# Pair models within the SAME sample/seed/regime; report signed RMSE difference.
full <- res[res$Model=='Full',]; red <- res[res$Model=='Reduced',]
paired <- merge(full,red,by=c('Seed','Sample_N','Regime'),suffixes=c('_Full','_Reduced'))
paired$RMSE_Difference_Reduced_Minus_Full <- paired$RMSE_Reduced-paired$RMSE_Full
paired$RMSE_Change_Percent <- 100*paired$RMSE_Difference_Reduced_Minus_Full/paired$RMSE_Full
write.csv(paired,file.path(outdir,'Sensitivity_Paired_Comparisons.csv'),row.names=FALSE)
# Across-seed means and ranges describe stability; three seeds are not an inferential CI.
summary <- aggregate(cbind(MAE,RMSE,R2)~Sample_N+Regime+Model,data=res,FUN=mean)
names(summary)[4:6] <- c('Mean_MAE','Mean_RMSE','Mean_R2')
ranges <- aggregate(RMSE~Sample_N+Regime+Model,data=res,FUN=function(x) c(min=min(x),max=max(x),sd=sd(x)))
ranges <- data.frame(ranges[c('Sample_N','Regime','Model')], Min_RMSE=ranges$RMSE[,'min'], Max_RMSE=ranges$RMSE[,'max'], SD_RMSE=ranges$RMSE[,'sd'])
summary <- merge(summary, ranges, by=c('Sample_N','Regime','Model'), sort=TRUE)
write.csv(summary,file.path(outdir,'Sensitivity_Summary.csv'),row.names=FALSE)
paired_summary <- aggregate(cbind(RMSE_Difference_Reduced_Minus_Full,RMSE_Change_Percent)~Sample_N+Regime,data=paired,FUN=mean)
write.csv(paired_summary,file.path(outdir,'Sensitivity_Paired_Summary.csv'),row.names=FALSE)
notes <- c('Sample-size sensitivity of full vs palate-aroma Random Forest; NOT original Table 6 replication.',
 paste('Input:',normalizePath(path)), 'Original eligible 1,048,340; excluded seven zero-appearance records; corrected eligible 1,048,333.',
 'Eligibility: complete sensory scores within 1-5; nonblank beer and reviewer IDs; ABV may be missing.',
 'Simple random subsamples without replacement for each seed and size; subsets across seeds and sizes may overlap.',
 'Three seeds: 123, 456, 789; sample sizes: 5,456, 20,000, 50,000.',
 'Group-disjoint approximately 80/20 train/test partitions; training-only ABV median imputation.',
 'RF: ranger 500 trees, mtry 1, minimum node 10, variance split, seed 123, single thread.',
 'No tuning on test data; the reduced model was previously chosen exploratorily; no external validation.',
 'Across-seed summaries are descriptive, not confidence intervals; sample sizes and splits differ from definitive Table 6.',
 capture.output(sessionInfo()))
writeLines(notes,file.path(outdir,'README_Sensitivity.txt'))
cat('\nCOMPLETED. Output directory:',outdir,'\n');print(summary);print(paired_summary)
