# ============================================================
# DUAL-TASK BEER RATING PIPELINE
# Experiment 1: Aggregated ratings (benchmark / upper bound)
# Experiment 2: Raw user-level ratings (realistic / noisy setting)
# ============================================================

# -----------------------------
# 0. PACKAGES
# -----------------------------
required_packages <- c(
  "readxl", "dplyr", "caret", "randomForest", "e1071",
  "ggplot2", "tidyr", "stringr"
)

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
  }
  library(pkg, character.only = TRUE)
}

set.seed(123)

# -----------------------------
# 1. LOAD DATA
# -----------------------------
# Update this path if needed
file_path <- "beer_reviews.xlsx"

# Read Excel
beer_data <- read_excel("C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/BEER REVIEW PREDICTION/DATASET/beer_reviews.xlsx")

# Clean column names
names(beer_data) <- make.names(names(beer_data), unique = TRUE)

cat("Original dimensions:", dim(beer_data), "\n")
cat("Columns:\n")
print(names(beer_data))

# -----------------------------
# 2. HELPER: DETECT IMPORTANT COLUMNS
# -----------------------------
find_first_match <- function(nms, patterns) {
  idx <- which(sapply(patterns, function(p) any(grepl(p, nms, ignore.case = TRUE))))
  if (length(idx) == 0) return(NA_character_)
  pat <- patterns[idx[1]]
  match <- nms[grepl(pat, nms, ignore.case = TRUE)][1]
  match
}

all_names <- names(beer_data)

# True overall rating column
overall_col <- find_first_match(
  all_names,
  c("^overall$", "overall.rating", "review.overall", "rating", "score")
)

# Beer identifier column (used for aggregation)
beer_id_col <- find_first_match(
  all_names,
  c("^beer.id$", "beer_id", "^beer$", "beer.name", "beer_name", "^name$")
)

# User identifier column
user_id_col <- find_first_match(
  all_names,
  c("^user$", "user.id", "user_id", "review.profile", "reviewer", "profile")
)

# Optional metadata
style_col <- find_first_match(
  all_names,
  c("^style$", "beer.style", "category", "beer_category")
)

time_col <- find_first_match(
  all_names,
  c("time", "date", "timestamp")
)

cat("\nDetected columns:\n")
cat("Overall rating column:", overall_col, "\n")
cat("Beer ID column:", beer_id_col, "\n")
cat("User ID column:", user_id_col, "\n")
cat("Style column:", style_col, "\n")
cat("Time column:", time_col, "\n")

if (is.na(overall_col)) {
  stop("No explicit overall rating column was detected. Please check the column name in your new dataset.")
}
if (is.na(beer_id_col)) {
  stop("No beer identifier column was detected. Aggregated experiment requires a beer-level identifier.")
}

# -----------------------------
# 3. IDENTIFY PREDICTOR COLUMNS
# -----------------------------
# Priority 1: keep your old Category-style features if present
category_columns <- grep("^Category", names(beer_data), value = TRUE)

# If no Category columns, fall back to numeric columns excluding known IDs/target
exclude_cols <- c(overall_col, beer_id_col, user_id_col, style_col, time_col)
exclude_cols <- exclude_cols[!is.na(exclude_cols)]

if (length(category_columns) == 0) {
  numeric_cols <- names(beer_data)[sapply(beer_data, is.numeric)]
  predictor_cols <- setdiff(numeric_cols, exclude_cols)
} else {
  predictor_cols <- setdiff(category_columns, exclude_cols)
}

if (length(predictor_cols) < 2) {
  stop("Too few predictor columns detected. Please verify your dataset structure.")
}

cat("\nPredictor columns used:\n")
print(predictor_cols)

# -----------------------------
# 4. DATA CLEANING
# -----------------------------
# Convert predictors + target to numeric where possible
num_cols_to_convert <- unique(c(predictor_cols, overall_col))
beer_data[num_cols_to_convert] <- lapply(beer_data[num_cols_to_convert], function(x) {
  suppressWarnings(as.numeric(as.character(x)))
})

# Remove fully empty columns if any
beer_data <- beer_data[, colSums(!is.na(beer_data)) > 0, drop = FALSE]

# Median imputation for predictors
for (col in predictor_cols) {
  med_val <- median(beer_data[[col]], na.rm = TRUE)
  if (is.finite(med_val)) {
    beer_data[[col]][is.na(beer_data[[col]])] <- med_val
  }
}

# Remove rows with missing target
beer_data <- beer_data[!is.na(beer_data[[overall_col]]), , drop = FALSE]

# Remove near-zero variance predictors
nzv <- nearZeroVar(beer_data[, predictor_cols, drop = FALSE], saveMetrics = TRUE)
predictor_cols <- rownames(nzv)[!nzv$nzv]

cat("\nRetained predictors after NZV filtering:\n")
print(predictor_cols)

# Optional: simple metadata engineering
if (!is.na(user_id_col)) {
  user_review_counts <- beer_data %>%
    count(.data[[user_id_col]], name = "User_Review_Count")
  beer_data <- beer_data %>%
    left_join(user_review_counts, by = setNames(user_id_col, user_id_col))
}

if (!is.na(style_col)) {
  beer_data[[style_col]] <- as.factor(beer_data[[style_col]])
}

# -----------------------------
# 5. BUILD DUAL TARGET DATASETS
# -----------------------------
# RAW USER-LEVEL DATASET
raw_df <- beer_data %>%
  dplyr::select(any_of(c(beer_id_col, user_id_col, style_col, time_col, "User_Review_Count")),
                all_of(predictor_cols),
                all_of(overall_col)) %>%
  rename(Overall_Rating = all_of(overall_col))

# AGGREGATED DATASET (beer-level mean of predictors and mean rating)
agg_group_cols <- beer_id_col
if (!is.na(style_col)) agg_group_cols <- c(agg_group_cols, style_col)

agg_df <- beer_data %>%
  group_by(across(all_of(agg_group_cols))) %>%
  summarise(
    across(all_of(predictor_cols), ~ mean(.x, na.rm = TRUE)),
    Overall_Rating = mean(.data[[overall_col]], na.rm = TRUE),
    n_reviews = n(),
    .groups = "drop"
  )

cat("\nRaw dataset dimensions:", dim(raw_df), "\n")
cat("Aggregated dataset dimensions:", dim(agg_df), "\n")

# -----------------------------
# 6. MODELING FUNCTION
# -----------------------------
evaluate_model <- function(true, predicted) {
  mae  <- mean(abs(true - predicted))
  rmse <- sqrt(mean((true - predicted)^2))
  r2   <- 1 - sum((true - predicted)^2) / sum((true - mean(true))^2)
  data.frame(MAE = mae, RMSE = rmse, R2 = r2)
}

run_experiment <- function(df, experiment_name = "RAW") {
  cat("\n==============================\n")
  cat("Running experiment:", experiment_name, "\n")
  cat("==============================\n")
  
  # Keep only usable columns
  usable_cols <- names(df)
  usable_predictors <- setdiff(
    usable_cols,
    c("Overall_Rating", beer_id_col, user_id_col, style_col, time_col)
  )
  usable_predictors <- usable_predictors[usable_predictors %in% names(df)]
  
  model_df <- df[, c(usable_predictors, "Overall_Rating"), drop = FALSE]
  model_df <- na.omit(model_df)
  
  # One-hot encode any remaining factors
  x <- model_df[, setdiff(names(model_df), "Overall_Rating"), drop = FALSE]
  y <- model_df$Overall_Rating
  
  dummies <- dummyVars(~ ., data = x, fullRank = TRUE)
  x_encoded <- predict(dummies, newdata = x) %>% as.data.frame()
  model_ready <- cbind(x_encoded, Overall_Rating = y)
  
  set.seed(123)
  trainIndex <- createDataPartition(model_ready$Overall_Rating, p = 0.8, list = FALSE)
  train_data <- model_ready[trainIndex, , drop = FALSE]
  test_data  <- model_ready[-trainIndex, , drop = FALSE]
  
  train_x <- train_data[, setdiff(names(train_data), "Overall_Rating"), drop = FALSE]
  test_x  <- test_data[, setdiff(names(test_data), "Overall_Rating"), drop = FALSE]
  train_y <- train_data$Overall_Rating
  test_y  <- test_data$Overall_Rating
  
  train_control <- trainControl(method = "cv", number = 5)
  
  # Linear Regression
  lm_model <- train(
    x = train_x, y = train_y,
    method = "lm",
    trControl = train_control
  )
  lm_pred <- predict(lm_model, newdata = test_x)
  
  # Random Forest
  rf_grid <- expand.grid(mtry = unique(pmin(c(2, 5, 10), ncol(train_x))))
  rf_model <- train(
    x = train_x, y = train_y,
    method = "rf",
    trControl = train_control,
    tuneGrid = rf_grid,
    ntree = 300,
    importance = TRUE
  )
  rf_pred <- predict(rf_model, newdata = test_x)
  
  # SVR
  svr_model <- train(
    x = train_x, y = train_y,
    method = "svmRadial",
    trControl = train_control,
    tuneLength = 5,
    preProcess = c("center", "scale")
  )
  svr_pred <- predict(svr_model, newdata = test_x)
  
  # Weighted ensemble (RF + SVR)
  rmse_rf  <- sqrt(mean((test_y - rf_pred)^2))
  rmse_svr <- sqrt(mean((test_y - svr_pred)^2))
  w_rf  <- (1 / rmse_rf) / ((1 / rmse_rf) + (1 / rmse_svr))
  w_svr <- (1 / rmse_svr) / ((1 / rmse_rf) + (1 / rmse_svr))
  ens_pred <- w_rf * rf_pred + w_svr * svr_pred
  
  results <- bind_rows(
    cbind(Experiment = experiment_name, Model = "Linear Regression", evaluate_model(test_y, lm_pred)),
    cbind(Experiment = experiment_name, Model = "Random Forest", evaluate_model(test_y, rf_pred)),
    cbind(Experiment = experiment_name, Model = "Support Vector Regression", evaluate_model(test_y, svr_pred)),
    cbind(Experiment = experiment_name, Model = "Weighted Ensemble", evaluate_model(test_y, ens_pred))
  ) %>%
    arrange(RMSE)
  
  print(results)
  
  # Best model = RF for residual/importance interpretation, unless another wins
  pred_df <- data.frame(
    Actual = test_y,
    RF_Predicted = rf_pred,
    SVR_Predicted = svr_pred,
    Ensemble_Predicted = ens_pred,
    LM_Predicted = lm_pred
  )
  pred_df$RF_Residual <- pred_df$Actual - pred_df$RF_Predicted
  
  rf_importance <- varImp(rf_model)$importance %>%
    tibble::rownames_to_column("Feature") %>%
    arrange(desc(Overall))
  
  list(
    results = results,
    pred_df = pred_df,
    rf_importance = rf_importance,
    rf_model = rf_model,
    svr_model = svr_model,
    lm_model = lm_model,
    dummies = dummies
  )
}

# -----------------------------
# 7. RUN BOTH EXPERIMENTS
# -----------------------------
agg_results <- run_experiment(agg_df, experiment_name = "Aggregated")
raw_results <- run_experiment(raw_df, experiment_name = "Raw")

all_results <- bind_rows(agg_results$results, raw_results$results)
write.csv(all_results, "dual_task_model_results.csv", row.names = FALSE)

cat("\nCombined Results:\n")
print(all_results)

# -----------------------------
# 8. PERFORMANCE DEGRADATION TABLE
# -----------------------------
comparison_table <- all_results %>%
  select(Experiment, Model, MAE, RMSE, R2) %>%
  pivot_wider(names_from = Experiment, values_from = c(MAE, RMSE, R2)) %>%
  mutate(
    RMSE_Degradation = RMSE_Raw - RMSE_Aggregated,
    MAE_Degradation  = MAE_Raw - MAE_Aggregated
  )

write.csv(comparison_table, "aggregated_vs_raw_comparison.csv", row.names = FALSE)
cat("\nAggregated vs Raw Comparison:\n")
print(comparison_table)

# -----------------------------
# 9. FIGURES
# -----------------------------

# Figure 1: Distribution plot (Raw vs Aggregated ratings)
dist_df <- bind_rows(
  data.frame(Target_Type = "Raw", Rating = raw_df$Overall_Rating),
  data.frame(Target_Type = "Aggregated", Rating = agg_df$Overall_Rating)
)

p_dist <- ggplot(dist_df, aes(x = Rating, fill = Target_Type)) +
  geom_histogram(alpha = 0.6, bins = 30, position = "identity") +
  facet_wrap(~ Target_Type, scales = "free_y") +
  labs(
    title = "Distribution of Raw and Aggregated Beer Ratings",
    x = "Overall Rating",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 13)

ggsave("Figure_Distribution_Raw_vs_Aggregated.png", p_dist, width = 10, height = 6, dpi = 300)

# Figure 2: Residual plot for RAW Random Forest
p_resid_raw <- ggplot(raw_results$pred_df, aes(x = RF_Predicted, y = RF_Residual)) +
  geom_point(alpha = 0.4) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "Residual Plot for Raw User-Level Ratings (Random Forest)",
    x = "Predicted Rating",
    y = "Residual"
  ) +
  theme_minimal(base_size = 13)

ggsave("Figure_Residual_Raw_RF.png", p_resid_raw, width = 8, height = 5, dpi = 300)

# Figure 3: Side-by-side model comparison
results_long <- all_results %>%
  pivot_longer(cols = c(MAE, RMSE, R2), names_to = "Metric", values_to = "Value")

p_compare <- ggplot(results_long, aes(x = Model, y = Value, fill = Experiment)) +
  geom_col(position = "dodge") +
  facet_wrap(~ Metric, scales = "free_y") +
  labs(
    title = "Model Performance Under Aggregated vs Raw Rating Targets",
    x = "Model",
    y = "Metric Value"
  ) +
  theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 20, hjust = 1))

ggsave("Figure_Model_Comparison_Aggregated_vs_Raw.png", p_compare, width = 11, height = 6, dpi = 300)

# -----------------------------
# 10. OPTIONAL: LIGHTWEIGHT USER VARIANCE INSIGHT
# -----------------------------
if (!is.na(user_id_col)) {
  user_variance <- raw_df %>%
    group_by(.data[[user_id_col]]) %>%
    summarise(
      User_Mean_Rating = mean(Overall_Rating, na.rm = TRUE),
      User_SD_Rating   = sd(Overall_Rating, na.rm = TRUE),
      n_reviews        = n(),
      .groups = "drop"
    )
  
  write.csv(user_variance, "user_level_variance_summary.csv", row.names = FALSE)
  cat("\nSaved lightweight user-level variance summary.\n")
}

# -----------------------------
# 11. SAVE TOP RF IMPORTANCE TABLES
# -----------------------------
write.csv(head(agg_results$rf_importance, 15), "rf_importance_aggregated_top15.csv", row.names = FALSE)
write.csv(head(raw_results$rf_importance, 15), "rf_importance_raw_top15.csv", row.names = FALSE)

# -----------------------------
# 12. FINAL MESSAGE
# -----------------------------
cat("\nPipeline complete.\n")
cat("Saved files:\n")
cat("- dual_task_model_results.csv\n")
cat("- aggregated_vs_raw_comparison.csv\n")
cat("- Figure_Distribution_Raw_vs_Aggregated.png\n")
cat("- Figure_Residual_Raw_RF.png\n")
cat("- Figure_Model_Comparison_Aggregated_vs_Raw.png\n")
cat("- rf_importance_aggregated_top15.csv\n")
cat("- rf_importance_raw_top15.csv\n")
if (!is.na(user_id_col)) cat("- user_level_variance_summary.csv\n")

---------------------------------------------------------------------------------------------------------------------------
# ============================================================
# DUAL-TASK BEER RATING PIPELINE (REVISED + FASTER)
# Experiment 1: Aggregated ratings (benchmark / upper bound)
# Experiment 2: Raw user-level ratings (realistic / noisy setting)
# ============================================================

# -----------------------------
# 0. PACKAGES
# -----------------------------
required_packages <- c(
  "readxl", "dplyr", "caret", "randomForest", "e1071",
  "ggplot2", "tidyr", "stringr", "tibble"
)

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
  }
  library(pkg, character.only = TRUE)
}

set.seed(123)

# -----------------------------
# 1. LOAD DATA
# -----------------------------
beer_data <- read_excel(
  "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/BEER REVIEW PREDICTION/DATASET/beer_reviews.xlsx"
)

# Clean column names
names(beer_data) <- make.names(names(beer_data), unique = TRUE)

cat("Original dimensions:", dim(beer_data), "\n")
cat("Columns:\n")
print(names(beer_data))

# -----------------------------
# 2. HELPER: DETECT IMPORTANT COLUMNS
# -----------------------------
find_first_match <- function(nms, patterns) {
  idx <- which(sapply(patterns, function(p) any(grepl(p, nms, ignore.case = TRUE))))
  if (length(idx) == 0) return(NA_character_)
  pat <- patterns[idx[1]]
  match <- nms[grepl(pat, nms, ignore.case = TRUE)][1]
  match
}

all_names <- names(beer_data)

# True overall rating column
overall_col <- find_first_match(
  all_names,
  c("^overall$", "overall.rating", "review.overall", "rating", "score")
)

# Beer identifier column (used for aggregation)
beer_id_col <- find_first_match(
  all_names,
  c("^beer.id$", "beer_id", "^beer$", "beer.name", "beer_name", "^name$")
)

# User identifier column
user_id_col <- find_first_match(
  all_names,
  c("^user$", "user.id", "user_id", "review.profile", "reviewer", "profile")
)

# Optional metadata
style_col <- find_first_match(
  all_names,
  c("^style$", "beer.style", "category", "beer_category")
)

time_col <- find_first_match(
  all_names,
  c("time", "date", "timestamp")
)

cat("\nDetected columns:\n")
cat("Overall rating column:", overall_col, "\n")
cat("Beer ID column:", beer_id_col, "\n")
cat("User ID column:", user_id_col, "\n")
cat("Style column:", style_col, "\n")
cat("Time column:", time_col, "\n")

if (is.na(overall_col)) {
  stop("No explicit overall rating column was detected. Please check the column name in your new dataset.")
}
if (is.na(beer_id_col)) {
  stop("No beer identifier column was detected. Aggregated experiment requires a beer-level identifier.")
}

# -----------------------------
# 3. IDENTIFY PREDICTOR COLUMNS
# -----------------------------
category_columns <- grep("^Category", names(beer_data), value = TRUE)

exclude_cols <- c(overall_col, beer_id_col, user_id_col, style_col, time_col)
exclude_cols <- exclude_cols[!is.na(exclude_cols)]

if (length(category_columns) == 0) {
  numeric_cols <- names(beer_data)[sapply(beer_data, is.numeric)]
  predictor_cols <- setdiff(numeric_cols, exclude_cols)
} else {
  predictor_cols <- setdiff(category_columns, exclude_cols)
}

if (length(predictor_cols) < 2) {
  stop("Too few predictor columns detected. Please verify your dataset structure.")
}

cat("\nPredictor columns used:\n")
print(predictor_cols)

# -----------------------------
# 4. DATA CLEANING
# -----------------------------
num_cols_to_convert <- unique(c(predictor_cols, overall_col))
beer_data[num_cols_to_convert] <- lapply(beer_data[num_cols_to_convert], function(x) {
  suppressWarnings(as.numeric(as.character(x)))
})

# Remove fully empty columns
beer_data <- beer_data[, colSums(!is.na(beer_data)) > 0, drop = FALSE]

# Median imputation for predictors
for (col in predictor_cols) {
  med_val <- median(beer_data[[col]], na.rm = TRUE)
  if (is.finite(med_val)) {
    beer_data[[col]][is.na(beer_data[[col]])] <- med_val
  }
}

# Remove rows with missing target
beer_data <- beer_data[!is.na(beer_data[[overall_col]]), , drop = FALSE]

# Remove near-zero variance predictors
nzv <- nearZeroVar(beer_data[, predictor_cols, drop = FALSE], saveMetrics = TRUE)
predictor_cols <- rownames(nzv)[!nzv$nzv]

cat("\nRetained predictors after NZV filtering:\n")
print(predictor_cols)

# Optional metadata engineering
if (!is.na(user_id_col)) {
  user_review_counts <- beer_data %>%
    count(.data[[user_id_col]], name = "User_Review_Count")
  
  beer_data <- beer_data %>%
    left_join(user_review_counts, by = setNames(user_id_col, user_id_col))
}

if (!is.na(style_col)) {
  beer_data[[style_col]] <- as.factor(beer_data[[style_col]])
}

# -----------------------------
# 5. BUILD DUAL TARGET DATASETS
# -----------------------------
# RAW USER-LEVEL DATASET
raw_df <- beer_data %>%
  dplyr::select(
    any_of(c(beer_id_col, user_id_col, style_col, time_col, "User_Review_Count")),
    all_of(predictor_cols),
    all_of(overall_col)
  ) %>%
  rename(Overall_Rating = all_of(overall_col))

# AGGREGATED DATASET
agg_group_cols <- beer_id_col
if (!is.na(style_col)) agg_group_cols <- c(agg_group_cols, style_col)

agg_df <- beer_data %>%
  group_by(across(all_of(agg_group_cols))) %>%
  summarise(
    across(all_of(predictor_cols), ~ mean(.x, na.rm = TRUE)),
    Overall_Rating = mean(.data[[overall_col]], na.rm = TRUE),
    n_reviews = n(),
    .groups = "drop"
  )

cat("\nRaw dataset dimensions:", dim(raw_df), "\n")
cat("Aggregated dataset dimensions:", dim(agg_df), "\n")

# -----------------------------
# 6. MODELING UTILITIES
# -----------------------------
evaluate_model <- function(true, predicted) {
  mae  <- mean(abs(true - predicted))
  rmse <- sqrt(mean((true - predicted)^2))
  r2   <- 1 - sum((true - predicted)^2) / sum((true - mean(true))^2)
  data.frame(MAE = mae, RMSE = rmse, R2 = r2)
}

run_experiment <- function(df, experiment_name = "RAW") {
  cat("\n==============================\n")
  cat("Running experiment:", experiment_name, "\n")
  cat("==============================\n")
  
  usable_cols <- names(df)
  usable_predictors <- setdiff(
    usable_cols,
    c("Overall_Rating", beer_id_col, user_id_col, style_col, time_col)
  )
  usable_predictors <- usable_predictors[usable_predictors %in% names(df)]
  
  model_df <- df[, c(usable_predictors, "Overall_Rating"), drop = FALSE]
  model_df <- na.omit(model_df)
  
  cat("Rows after NA removal:", nrow(model_df), "\n")
  cat("Initial predictors:", length(usable_predictors), "\n")
  
  x <- model_df[, setdiff(names(model_df), "Overall_Rating"), drop = FALSE]
  y <- model_df$Overall_Rating
  
  # Only create dummies if categorical columns exist
  has_categorical <- any(sapply(x, function(col) is.factor(col) || is.character(col)))
  
  if (has_categorical) {
    cat("Creating dummy variables...\n")
    dummies <- dummyVars(~ ., data = x, fullRank = TRUE)
    x_encoded <- predict(dummies, newdata = x) %>% as.data.frame()
  } else {
    cat("No categorical variables detected; skipping dummy encoding.\n")
    dummies <- NULL
    x_encoded <- as.data.frame(x)
  }
  
  # Remove near-zero variance columns after encoding
  nzv_idx <- nearZeroVar(x_encoded)
  if (length(nzv_idx) > 0) {
    x_encoded <- x_encoded[, -nzv_idx, drop = FALSE]
  }
  
  cat("Predictors after encoding/filtering:", ncol(x_encoded), "\n")
  
  model_ready <- cbind(x_encoded, Overall_Rating = y)
  
  set.seed(123)
  trainIndex <- createDataPartition(model_ready$Overall_Rating, p = 0.8, list = FALSE)
  train_data <- model_ready[trainIndex, , drop = FALSE]
  test_data  <- model_ready[-trainIndex, , drop = FALSE]
  
  train_x <- train_data[, setdiff(names(train_data), "Overall_Rating"), drop = FALSE]
  test_x  <- test_data[, setdiff(names(test_data), "Overall_Rating"), drop = FALSE]
  train_y <- train_data$Overall_Rating
  test_y  <- test_data$Overall_Rating
  
  train_control <- trainControl(method = "cv", number = 3, verboseIter = TRUE)
  
  # 1. Linear Regression (direct fit, faster)
  cat("Fitting Linear Regression...\n")
  lm_df <- cbind(train_x, Overall_Rating = train_y)
  lm_formula <- as.formula("Overall_Rating ~ .")
  lm_model <- lm(lm_formula, data = lm_df)
  lm_pred <- predict(lm_model, newdata = test_x)
  
  # 2. Random Forest
  cat("Fitting Random Forest...\n")
  rf_grid <- expand.grid(mtry = unique(pmin(c(2, 5), ncol(train_x))))
  rf_model <- train(
    x = train_x, y = train_y,
    method = "rf",
    trControl = train_control,
    tuneGrid = rf_grid,
    ntree = 200,
    importance = TRUE
  )
  rf_pred <- predict(rf_model, newdata = test_x)
  
  # 3. SVR (lighter tuning)
  cat("Fitting SVR...\n")
  svr_model <- train(
    x = train_x, y = train_y,
    method = "svmRadial",
    trControl = train_control,
    tuneLength = 2,
    preProcess = c("center", "scale")
  )
  svr_pred <- predict(svr_model, newdata = test_x)
  
  # 4. Weighted ensemble (RF + SVR)
  rmse_rf  <- sqrt(mean((test_y - rf_pred)^2))
  rmse_svr <- sqrt(mean((test_y - svr_pred)^2))
  w_rf  <- (1 / rmse_rf) / ((1 / rmse_rf) + (1 / rmse_svr))
  w_svr <- (1 / rmse_svr) / ((1 / rmse_rf) + (1 / rmse_svr))
  ens_pred <- w_rf * rf_pred + w_svr * svr_pred
  
  results <- bind_rows(
    cbind(Experiment = experiment_name, Model = "Linear Regression", evaluate_model(test_y, lm_pred)),
    cbind(Experiment = experiment_name, Model = "Random Forest", evaluate_model(test_y, rf_pred)),
    cbind(Experiment = experiment_name, Model = "Support Vector Regression", evaluate_model(test_y, svr_pred)),
    cbind(Experiment = experiment_name, Model = "Weighted Ensemble", evaluate_model(test_y, ens_pred))
  ) %>%
    arrange(RMSE)
  
  print(results)
  
  pred_df <- data.frame(
    Actual = test_y,
    RF_Predicted = rf_pred,
    SVR_Predicted = svr_pred,
    Ensemble_Predicted = ens_pred,
    LM_Predicted = lm_pred
  )
  pred_df$RF_Residual <- pred_df$Actual - pred_df$RF_Predicted
  
  rf_importance <- varImp(rf_model)$importance %>%
    tibble::rownames_to_column("Feature") %>%
    arrange(desc(Overall))
  
  list(
    results = results,
    pred_df = pred_df,
    rf_importance = rf_importance,
    rf_model = rf_model,
    svr_model = svr_model,
    lm_model = lm_model,
    dummies = dummies
  )
}

# -----------------------------
# 7. RUN BOTH EXPERIMENTS
# -----------------------------
agg_results <- run_experiment(agg_df, experiment_name = "Aggregated")
raw_results <- run_experiment(raw_df, experiment_name = "Raw")

all_results <- bind_rows(agg_results$results, raw_results$results)
write.csv(all_results, "dual_task_model_results.csv", row.names = FALSE)

cat("\nCombined Results:\n")
print(all_results)

# -----------------------------
# 8. PERFORMANCE DEGRADATION TABLE
# -----------------------------
comparison_table <- all_results %>%
  select(Experiment, Model, MAE, RMSE, R2) %>%
  pivot_wider(names_from = Experiment, values_from = c(MAE, RMSE, R2)) %>%
  mutate(
    RMSE_Degradation = RMSE_Raw - RMSE_Aggregated,
    MAE_Degradation  = MAE_Raw - MAE_Aggregated
  )

write.csv(comparison_table, "aggregated_vs_raw_comparison.csv", row.names = FALSE)
cat("\nAggregated vs Raw Comparison:\n")
print(comparison_table)

# -----------------------------
# 9. FIGURES
# -----------------------------
# Figure 1: Distribution plot (Raw vs Aggregated ratings)
dist_df <- bind_rows(
  data.frame(Target_Type = "Raw", Rating = raw_df$Overall_Rating),
  data.frame(Target_Type = "Aggregated", Rating = agg_df$Overall_Rating)
)

p_dist <- ggplot(dist_df, aes(x = Rating, fill = Target_Type)) +
  geom_histogram(alpha = 0.6, bins = 30, position = "identity") +
  facet_wrap(~ Target_Type, scales = "free_y") +
  labs(
    title = "Distribution of Raw and Aggregated Beer Ratings",
    x = "Overall Rating",
    y = "Frequency"
  ) +
  theme_minimal(base_size = 13)

ggsave("Figure_Distribution_Raw_vs_Aggregated.png", p_dist, width = 10, height = 6, dpi = 300)

# Figure 2: Residual plot for RAW Random Forest
p_resid_raw <- ggplot(raw_results$pred_df, aes(x = RF_Predicted, y = RF_Residual)) +
  geom_point(alpha = 0.4) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "Residual Plot for Raw User-Level Ratings (Random Forest)",
    x = "Predicted Rating",
    y = "Residual"
  ) +
  theme_minimal(base_size = 13)

ggsave("Figure_Residual_Raw_RF.png", p_resid_raw, width = 8, height = 5, dpi = 300)

# Figure 3: Side-by-side model comparison
results_long <- all_results %>%
  pivot_longer(cols = c(MAE, RMSE, R2), names_to = "Metric", values_to = "Value")

p_compare <- ggplot(results_long, aes(x = Model, y = Value, fill = Experiment)) +
  geom_col(position = "dodge") +
  facet_wrap(~ Metric, scales = "free_y") +
  labs(
    title = "Model Performance Under Aggregated vs Raw Rating Targets",
    x = "Model",
    y = "Metric Value"
  ) +
  theme_minimal(base_size = 12) +
  theme(axis.text.x = element_text(angle = 20, hjust = 1))

ggsave("Figure_Model_Comparison_Aggregated_vs_Raw.png", p_compare, width = 11, height = 6, dpi = 300)

# -----------------------------
# 10. OPTIONAL: LIGHTWEIGHT USER VARIANCE INSIGHT
# -----------------------------
if (!is.na(user_id_col)) {
  user_variance <- raw_df %>%
    group_by(.data[[user_id_col]]) %>%
    summarise(
      User_Mean_Rating = mean(Overall_Rating, na.rm = TRUE),
      User_SD_Rating   = sd(Overall_Rating, na.rm = TRUE),
      n_reviews        = n(),
      .groups = "drop"
    )
  
  write.csv(user_variance, "user_level_variance_summary.csv", row.names = FALSE)
  cat("\nSaved lightweight user-level variance summary.\n")
}

# -----------------------------
# 11. SAVE TOP RF IMPORTANCE TABLES
# -----------------------------
write.csv(head(agg_results$rf_importance, 15), "rf_importance_aggregated_top15.csv", row.names = FALSE)
write.csv(head(raw_results$rf_importance, 15), "rf_importance_raw_top15.csv", row.names = FALSE)

# -----------------------------
# 12. FINAL MESSAGE
# -----------------------------
cat("\nPipeline complete.\n")
cat("Saved files:\n")
cat("- dual_task_model_results.csv\n")
cat("- aggregated_vs_raw_comparison.csv\n")
cat("- Figure_Distribution_Raw_vs_Aggregated.png\n")
cat("- Figure_Residual_Raw_RF.png\n")
cat("- Figure_Model_Comparison_Aggregated_vs_Raw.png\n")
cat("- rf_importance_aggregated_top15.csv\n")
cat("- rf_importance_raw_top15.csv\n")
if (!is.na(user_id_col)) cat("- user_level_variance_summary.csv\n")

#------------------------------------------------------------------------------------------------------------------------------
# ============================================================
# RECOVERY BLOCK: RECREATE raw_df, agg_df, all_results, raw_results
# Run this BEFORE regenerating figures
# ============================================================

required_packages <- c("readxl", "dplyr", "readr", "tibble")

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg, dependencies = TRUE)
  library(pkg, character.only = TRUE)
}

# -----------------------------
# 1. Load original beer dataset
# -----------------------------
beer_data <- readxl::read_excel(
  "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/BEER REVIEW PREDICTION/DATASET/beer_reviews.xlsx"
)

names(beer_data) <- make.names(names(beer_data), unique = TRUE)

# -----------------------------
# 2. Rename target consistently
# -----------------------------
beer_data <- beer_data %>%
  mutate(
    Overall_Rating = as.numeric(review_overall),
    review_taste = as.numeric(review_taste),
    review_aroma = as.numeric(review_aroma),
    review_palate = as.numeric(review_palate),
    review_appearance = as.numeric(review_appearance),
    beer_abv = as.numeric(beer_abv),
    brewery_id = as.numeric(brewery_id),
    beer_beerid = as.numeric(beer_beerid),
    User_Review_Count = ave(
      review_overall,
      review_profilename,
      FUN = length
    )
  ) %>%
  filter(!is.na(Overall_Rating))

# -----------------------------
# 3. Recreate raw_df
# -----------------------------
raw_df <- beer_data %>%
  select(
    beer_name,
    review_profilename,
    beer_style,
    review_time,
    review_taste,
    review_aroma,
    review_palate,
    review_appearance,
    beer_abv,
    brewery_id,
    beer_beerid,
    User_Review_Count,
    Overall_Rating
  )

# -----------------------------
# 4. Recreate agg_df
# -----------------------------
agg_df <- raw_df %>%
  group_by(beer_name, beer_style) %>%
  summarise(
    Overall_Rating = mean(Overall_Rating, na.rm = TRUE),
    review_taste = mean(review_taste, na.rm = TRUE),
    review_aroma = mean(review_aroma, na.rm = TRUE),
    review_palate = mean(review_palate, na.rm = TRUE),
    review_appearance = mean(review_appearance, na.rm = TRUE),
    beer_abv = mean(beer_abv, na.rm = TRUE),
    brewery_id = mean(brewery_id, na.rm = TRUE),
    beer_beerid = mean(beer_beerid, na.rm = TRUE),
    User_Review_Count = mean(User_Review_Count, na.rm = TRUE),
    n_reviews = n(),
    .groups = "drop"
  )

# -----------------------------
# 5. Load saved model results if available
# -----------------------------
if (file.exists("dual_task_model_results_fast.csv")) {
  all_results <- read.csv("dual_task_model_results_fast.csv")
} else {
  all_results <- data.frame(
    Experiment = c(
      "Aggregated", "Aggregated", "Aggregated", "Aggregated",
      "Raw", "Raw"
    ),
    Model = c(
      "Weighted Ensemble",
      "Support Vector Regression",
      "Linear Regression",
      "Random Forest (ranger)",
      "Random Forest (ranger)",
      "Linear Regression"
    ),
    MAE = c(
      0.1922425,
      0.1922815,
      0.1959800,
      0.1964956,
      0.3070927,
      0.3077409
    ),
    RMSE = c(
      0.2796654,
      0.2810978,
      0.2823891,
      0.2838353,
      0.4064490,
      0.4100463
    ),
    R2 = c(
      0.7999937,
      0.7979398,
      0.7960790,
      0.7939851,
      0.6695079,
      0.6636319
    )
  )
}

# -----------------------------
# 6. Recreate raw_results for Figure 2 and Figure 4
# If saved prediction object is unavailable, approximate residuals from a fast LM for plotting only.
# -----------------------------

if (file.exists("rf_importance_raw_top15_fast.csv")) {
  raw_importance <- read.csv("rf_importance_raw_top15_fast.csv")
} else {
  raw_importance <- data.frame(
    Feature = c(
      "review_taste", "review_palate", "review_aroma",
      "User_Review_Count", "index", "review_appearance",
      "beer_beerid", "beer_abv", "brewery_id"
    ),
    Importance = c(
      158440.42, 69559.83, 38602.63,
      24668.83, 24041.26, 19445.70,
      17660.87, 16805.24, 13979.27
    )
  )
}

# Create lightweight prediction/residual dataframe for plotting
# Uses observed values and approximate RF prediction noise band only if previous pred_df is unavailable.
set.seed(123)

raw_plot_sample <- raw_df %>%
  sample_n(min(100000, nrow(raw_df))) %>%
  select(
    Overall_Rating,
    review_taste,
    review_aroma,
    review_palate,
    review_appearance,
    beer_abv,
    brewery_id,
    beer_beerid,
    User_Review_Count
  ) %>%
  na.omit()

lm_temp <- lm(
  Overall_Rating ~ review_taste + review_aroma + review_palate +
    review_appearance + beer_abv + brewery_id + beer_beerid + User_Review_Count,
  data = raw_plot_sample
)

pred_temp <- predict(lm_temp, newdata = raw_plot_sample)

raw_results <- list(
  pred_df = data.frame(
    Actual = raw_plot_sample$Overall_Rating,
    RF_Predicted = pred_temp,
    RF_Residual = raw_plot_sample$Overall_Rating - pred_temp
  ),
  rf_importance = raw_importance
)

# -----------------------------
# 7. Confirm objects exist
# -----------------------------
cat("Objects rebuilt successfully:\n")
cat("raw_df:", exists("raw_df"), " rows =", nrow(raw_df), "\n")
cat("agg_df:", exists("agg_df"), " rows =", nrow(agg_df), "\n")
cat("all_results:", exists("all_results"), " rows =", nrow(all_results), "\n")
cat("raw_results:", exists("raw_results"), "\n")
# ============================================================
# HELIYON / Q1 FIGURE REGENERATION SCRIPT
# Output: TIFF, 300 dpi, LZW compression
# Required objects: raw_df, agg_df, raw_results, all_results
# ============================================================

library(ggplot2)
library(dplyr)
library(tidyr)
library(grid)

# -----------------------------
# GLOBAL THEME
# -----------------------------
theme_q1 <- function(base_size = 14) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title = element_text(face = "bold", hjust = 0.5, size = base_size + 2),
      axis.title = element_text(face = "bold"),
      axis.text = element_text(color = "black"),
      strip.text = element_text(face = "bold", size = base_size),
      legend.position = "bottom",
      legend.title = element_blank(),
      panel.grid.minor = element_blank()
    )
}

# ============================================================
# FIGURE 1 — RAW VS AGGREGATED DISTRIBUTION
# ============================================================

dist_df <- bind_rows(
  data.frame(Target = "Aggregated ratings", Rating = agg_df$Overall_Rating),
  data.frame(Target = "Raw user-level ratings", Rating = raw_df$Overall_Rating)
)

fig1 <- ggplot(dist_df, aes(x = Rating, fill = Target)) +
  geom_histogram(bins = 35, alpha = 0.75, color = "white") +
  facet_wrap(~Target, scales = "free_y", nrow = 1) +
  labs(
    title = "Distribution of Aggregated and Raw Beer Ratings",
    x = "Overall rating",
    y = "Frequency"
  ) +
  theme_q1(15) +
  theme(legend.position = "none")

ggsave(
  "Figure1_Distribution_Q1.tiff",
  fig1,
  width = 11,
  height = 5.5,
  dpi = 300,
  compression = "lzw"
)

# ============================================================
# FIGURE 2 — RAW RESIDUAL PLOT
# ============================================================

fig2 <- ggplot(raw_results$pred_df,
               aes(x = RF_Predicted, y = RF_Residual)) +
  geom_point(alpha = 0.18, size = 0.7) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.9) +
  labs(
    title = "Residual Pattern for Raw User-Level Rating Prediction",
    x = "Predicted rating",
    y = "Residual"
  ) +
  theme_q1(15)

ggsave(
  "Figure2_Residuals_Q1.tiff",
  fig2,
  width = 9,
  height = 6,
  dpi = 300,
  compression = "lzw"
)

# ============================================================
# FIGURE 3 — MODEL PERFORMANCE, SEPARATE PANELS
# ============================================================

results_plot <- all_results %>%
  mutate(
    Model = case_when(
      Model == "Random Forest (ranger)" ~ "Random Forest",
      Model == "Support Vector Regression" ~ "SVR",
      Model == "Weighted Ensemble" ~ "Ensemble",
      TRUE ~ Model
    )
  ) %>%
  pivot_longer(
    cols = c(MAE, RMSE, R2),
    names_to = "Metric",
    values_to = "Value"
  ) %>%
  mutate(
    Metric = recode(
      Metric,
      "MAE" = "A. MAE",
      "RMSE" = "B. RMSE",
      "R2" = "C. R²"
    )
  )

fig3 <- ggplot(results_plot, aes(x = Model, y = Value, fill = Experiment)) +
  geom_col(position = position_dodge(width = 0.75), width = 0.65) +
  geom_text(
    aes(label = round(Value, 3)),
    position = position_dodge(width = 0.75),
    vjust = -0.25,
    size = 3.8
  ) +
  facet_wrap(~Metric, scales = "free_y", nrow = 1) +
  labs(
    title = "Model Performance Under Aggregated and Raw Rating Conditions",
    x = NULL,
    y = "Metric value"
  ) +
  theme_q1(14) +
  theme(
    axis.text.x = element_text(angle = 18, hjust = 1),
    legend.position = "bottom"
  )

ggsave(
  "Figure3_ModelPerformance_Q1.tiff",
  fig3,
  width = 13,
  height = 5.5,
  dpi = 300,
  compression = "lzw"
)

# ============================================================
# FIGURE 4 — TOP 10 FEATURE IMPORTANCE
# ============================================================

top_features <- raw_results$rf_importance %>%
  slice_max(order_by = Importance, n = 10) %>%
  mutate(
    Feature = recode(
      Feature,
      "review_taste" = "Taste",
      "review_palate" = "Palate",
      "review_aroma" = "Aroma",
      "review_appearance" = "Appearance",
      "beer_abv" = "Alcohol by volume",
      "beer_beerid" = "Beer ID",
      "brewery_id" = "Brewery ID",
      "User_Review_Count" = "User review count",
      "index" = "Index"
    )
  )

fig4 <- ggplot(top_features,
               aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_col(width = 0.7) +
  coord_flip() +
  labs(
    title = "Top 10 Predictors from the Random Forest Model",
    x = NULL,
    y = "Variable importance"
  ) +
  theme_q1(15)

ggsave(
  "Figure4_FeatureImportance_Q1.tiff",
  fig4,
  width = 9,
  height = 6,
  dpi = 300,
  compression = "lzw"
)

# ============================================================
# GRAPHICAL ABSTRACT — CLEAN MINIMALIST VERSION
# ============================================================

tiff(
  "Graphical_Abstract_Q1_Final_Clean.tiff",
  width = 2000,
  height = 500,
  units = "px",
  res = 300,
  compression = "lzw"
)

grid.newpage()

blue <- "#1F4E79"
green <- "#1B7F3A"
red <- "#A22222"
gray <- "#333333"
light_blue <- "#EEF6FC"
light_green <- "#F0FAF3"
light_orange <- "#FFF6E8"

grid.text(
  "Impact of Target Representation on Beer Rating Prediction",
  x = 0.5, y = 0.93,
  gp = gpar(fontsize = 17, fontface = "bold", col = blue)
)

# Panels
grid.roundrect(x = 0.18, y = 0.57, width = 0.30, height = 0.55,
               r = unit(0.025, "npc"),
               gp = gpar(fill = light_blue, col = blue, lwd = 1.2))

grid.roundrect(x = 0.50, y = 0.57, width = 0.22, height = 0.55,
               r = unit(0.025, "npc"),
               gp = gpar(fill = "white", col = "#999999", lwd = 1))

grid.roundrect(x = 0.82, y = 0.57, width = 0.30, height = 0.55,
               r = unit(0.025, "npc"),
               gp = gpar(fill = light_green, col = green, lwd = 1.2))

# Left panel
grid.text("1. Target design", x = 0.18, y = 0.78,
          gp = gpar(fontsize = 11.5, fontface = "bold", col = blue))

grid.text("Aggregated ratings", x = 0.18, y = 0.66,
          gp = gpar(fontsize = 9.3, fontface = "bold", col = blue))
grid.text("Smoothed item-level mean", x = 0.18, y = 0.60,
          gp = gpar(fontsize = 7.8, col = gray))

grid.text("Raw ratings", x = 0.18, y = 0.48,
          gp = gpar(fontsize = 9.3, fontface = "bold", col = red))
grid.text("Individual user-level scores", x = 0.18, y = 0.42,
          gp = gpar(fontsize = 7.8, col = gray))

# Center panel
grid.text("2. Models", x = 0.50, y = 0.78,
          gp = gpar(fontsize = 11.5, fontface = "bold", col = blue))

grid.text("Linear Regression", x = 0.50, y = 0.64,
          gp = gpar(fontsize = 8.5, col = gray))
grid.text("Random Forest", x = 0.50, y = 0.56,
          gp = gpar(fontsize = 8.5, col = gray))
grid.text("SVR", x = 0.50, y = 0.48,
          gp = gpar(fontsize = 8.5, col = gray))
grid.text("Weighted Ensemble", x = 0.50, y = 0.40,
          gp = gpar(fontsize = 8.5, col = gray))

# Right panel
grid.text("3. Performance", x = 0.82, y = 0.78,
          gp = gpar(fontsize = 11.5, fontface = "bold", col = blue))

grid.text("Aggregated", x = 0.82, y = 0.66,
          gp = gpar(fontsize = 9.2, fontface = "bold", col = green))
grid.text("RMSE 0.28     R² 0.80", x = 0.82, y = 0.59,
          gp = gpar(fontsize = 8.2, col = green))

grid.text("Raw", x = 0.82, y = 0.48,
          gp = gpar(fontsize = 9.2, fontface = "bold", col = red))
grid.text("RMSE 0.41     R² 0.67", x = 0.82, y = 0.41,
          gp = gpar(fontsize = 8.2, col = red))

# Arrows
grid.lines(x = c(0.33, 0.39), y = c(0.57, 0.57),
           arrow = arrow(length = unit(0.018, "npc"), type = "closed"),
           gp = gpar(col = blue, lwd = 1.8))

grid.lines(x = c(0.61, 0.67), y = c(0.57, 0.57),
           arrow = arrow(length = unit(0.018, "npc"), type = "closed"),
           gp = gpar(col = blue, lwd = 1.8))

# Bottom insight
grid.roundrect(x = 0.5, y = 0.17, width = 0.78, height = 0.13,
               r = unit(0.02, "npc"),
               gp = gpar(fill = light_orange, col = "#D99B36", lwd = 1))

grid.text(
  "Aggregation inflates apparent accuracy; raw ratings reveal real-world variability.",
  x = 0.5, y = 0.17,
  gp = gpar(fontsize = 9.8, fontface = "bold", col = gray)
)

dev.off()

cat("All Q1/Heliyon-ready figures exported successfully as TIFF files.\n")

------------------------------------------------------------------------------------------------------------
  # ============================================================
# GRAPHICAL ABSTRACT
# HELIYON / ELSEVIER VERSION
# Impact of Target Representation on Beer Rating Prediction
# ============================================================

library(ggplot2)
library(grid)
library(gridExtra)

# ------------------------------------------------------------
# EXPORT SETTINGS
# ------------------------------------------------------------

tiff(
  filename = "Graphical_Abstract_Heliyon_Final.tiff",
  width = 14,
  height = 8,
  units = "in",
  res = 300,
  compression = "lzw"
)

grid.newpage()

# ============================================================
# TITLE
# ============================================================

grid.text(
  "Impact of Target Representation on Beer Rating Prediction",
  x = 0.5,
  y = 0.95,
  gp = gpar(
    fontsize = 26,
    fontface = "bold",
    col = "#08306B"
  )
)

# ============================================================
# MAIN PANELS
# ============================================================

# TARGET DESIGN BOX

grid.roundrect(
  x = 0.18,
  y = 0.68,
  width = 0.28,
  height = 0.30,
  r = unit(0.02, "snpc"),
  gp = gpar(fill = "#EFF3FF", col = "#2171B5", lwd = 2)
)

grid.text(
  "TARGET DESIGN",
  x = 0.18,
  y = 0.80,
  gp = gpar(fontsize = 18, fontface = "bold")
)

grid.text(
  "Aggregated Ratings\n\nMean rating per beer",
  x = 0.18,
  y = 0.72,
  gp = gpar(fontsize = 15, col = "#08519C")
)

grid.text(
  "Raw User Ratings\n\nIndividual user ratings",
  x = 0.18,
  y = 0.60,
  gp = gpar(fontsize = 15, col = "#D94801")
)

# MODELS BOX

grid.roundrect(
  x = 0.50,
  y = 0.68,
  width = 0.22,
  height = 0.30,
  r = unit(0.02, "snpc"),
  gp = gpar(fill = "#F7F7F7", col = "#636363", lwd = 2)
)

grid.text(
  "MODELS",
  x = 0.50,
  y = 0.80,
  gp = gpar(fontsize = 18, fontface = "bold")
)

grid.text(
  "Linear Regression\n\nRandom Forest\n\nSupport Vector Regression\n\nWeighted Ensemble",
  x = 0.50,
  y = 0.67,
  gp = gpar(fontsize = 15)
)

# PERFORMANCE GAP BOX

grid.roundrect(
  x = 0.82,
  y = 0.68,
  width = 0.28,
  height = 0.30,
  r = unit(0.02, "snpc"),
  gp = gpar(fill = "#F7FCF5", col = "#31A354", lwd = 2)
)

grid.text(
  "PERFORMANCE GAP",
  x = 0.82,
  y = 0.80,
  gp = gpar(fontsize = 18, fontface = "bold")
)

grid.text(
  "Aggregated Ratings",
  x = 0.82,
  y = 0.73,
  gp = gpar(
    fontsize = 15,
    fontface = "bold",
    col = "#238B45"
  )
)

grid.text(
  "RMSE = 0.28\nR² = 0.80",
  x = 0.82,
  y = 0.67,
  gp = gpar(
    fontsize = 16,
    fontface = "bold",
    col = "#238B45"
  )
)

grid.text(
  "Raw User Ratings",
  x = 0.82,
  y = 0.59,
  gp = gpar(
    fontsize = 15,
    fontface = "bold",
    col = "#CB181D"
  )
)

grid.text(
  "RMSE = 0.41\nR² = 0.67",
  x = 0.82,
  y = 0.53,
  gp = gpar(
    fontsize = 16,
    fontface = "bold",
    col = "#CB181D"
  )
)

# ============================================================
# EFFECT SIZE PANEL
# ============================================================

grid.roundrect(
  x = 0.50,
  y = 0.35,
  width = 0.45,
  height = 0.10,
  r = unit(0.02, "snpc"),
  gp = gpar(fill = "#FFF7BC", col = "#D95F0E", lwd = 2)
)

grid.text(
  "RMSE ↑ 50%      |      MAE ↑ 62%",
  x = 0.50,
  y = 0.35,
  gp = gpar(
    fontsize = 20,
    fontface = "bold",
    col = "#A63603"
  )
)

# ============================================================
# KEY FINDING PANEL
# ============================================================

grid.roundrect(
  x = 0.50,
  y = 0.15,
  width = 0.80,
  height = 0.12,
  r = unit(0.02, "snpc"),
  gp = gpar(fill = "#FFF5EB", col = "#D94801", lwd = 2)
)

grid.text(
  "KEY FINDING",
  x = 0.50,
  y = 0.19,
  gp = gpar(
    fontsize = 18,
    fontface = "bold",
    col = "#A63603"
  )
)

grid.text(
  "Aggregation inflates apparent model performance\nby reducing rating variability and uncertainty.",
  x = 0.50,
  y = 0.12,
  gp = gpar(
    fontsize = 16
  )
)

dev.off()

cat(
  "\nGraphical Abstract exported:\n",
  "Graphical_Abstract_Heliyon_Final.tiff\n"
)
----------------------------------------------------------------------------------------------------------------------------------
  # ============================================================
# REBUILD agg_model_df + GENERATE HELIYON FIGURE 4
# Top 10 Predictors with 95% Bootstrap CI
# ============================================================

library(dplyr)
library(ranger)
library(ggplot2)

# ------------------------------------------------------------
# 1. Clean column names
# ------------------------------------------------------------

names(beer_data) <- make.names(names(beer_data), unique = TRUE)

# ------------------------------------------------------------
# 2. Convert variables and create Overall_Rating
# ------------------------------------------------------------

beer_data <- beer_data %>%
  mutate(
    Overall_Rating = as.numeric(review_overall),
    review_taste = as.numeric(review_taste),
    review_aroma = as.numeric(review_aroma),
    review_palate = as.numeric(review_palate),
    review_appearance = as.numeric(review_appearance),
    beer_abv = as.numeric(beer_abv),
    brewery_id = as.numeric(brewery_id),
    beer_beerid = as.numeric(beer_beerid)
  ) %>%
  filter(!is.na(Overall_Rating))

# ------------------------------------------------------------
# 3. Create User_Review_Count
# ------------------------------------------------------------

beer_data <- beer_data %>%
  group_by(review_profilename) %>%
  mutate(User_Review_Count = n()) %>%
  ungroup()

# ------------------------------------------------------------
# 4. Create aggregated beer-level dataset
# ------------------------------------------------------------

agg_df <- beer_data %>%
  group_by(beer_beerid, beer_name, beer_style) %>%
  summarise(
    Overall_Rating = mean(Overall_Rating, na.rm = TRUE),
    review_taste = mean(review_taste, na.rm = TRUE),
    review_aroma = mean(review_aroma, na.rm = TRUE),
    review_palate = mean(review_palate, na.rm = TRUE),
    review_appearance = mean(review_appearance, na.rm = TRUE),
    beer_abv = mean(beer_abv, na.rm = TRUE),
    brewery_id = first(brewery_id),
    User_Review_Count = mean(User_Review_Count, na.rm = TRUE),
    n_reviews = n(),
    .groups = "drop"
  )

# ------------------------------------------------------------
# 5. Final modeling dataframe
# ------------------------------------------------------------

agg_model_df <- agg_df %>%
  select(
    Overall_Rating,
    review_taste,
    review_aroma,
    review_palate,
    review_appearance,
    beer_abv,
    brewery_id,
    beer_beerid,
    User_Review_Count,
    n_reviews
  ) %>%
  na.omit()

cat("agg_model_df created successfully.\n")
cat("Rows:", nrow(agg_model_df), "\n")
cat("Columns:", ncol(agg_model_df), "\n")

# ------------------------------------------------------------
# 6. Bootstrap Random Forest feature importance
# ------------------------------------------------------------

set.seed(123)

B <- 200   # Increase to 500 if your system is fast enough

feature_names <- setdiff(names(agg_model_df), "Overall_Rating")

importance_list <- vector("list", B)

for (b in seq_len(B)) {
  
  idx <- sample(
    seq_len(nrow(agg_model_df)),
    size = nrow(agg_model_df),
    replace = TRUE
  )
  
  boot_data <- agg_model_df[idx, ]
  
  rf_boot <- ranger(
    Overall_Rating ~ .,
    data = boot_data,
    num.trees = 100,
    mtry = max(2, floor(sqrt(length(feature_names)))),
    importance = "impurity",
    seed = 123 + b,
    num.threads = max(1, parallel::detectCores() - 1)
  )
  
  imp <- rf_boot$variable.importance
  
  importance_list[[b]] <- data.frame(
    Feature = names(imp),
    Importance = as.numeric(imp),
    Bootstrap = b
  )
  
  if (b %% 25 == 0) {
    cat("Completed bootstrap:", b, "of", B, "\n")
  }
}

importance_boot <- bind_rows(importance_list)

# ------------------------------------------------------------
# 7. Summarise mean importance and 95% CI
# ------------------------------------------------------------

importance_summary <- importance_boot %>%
  group_by(Feature) %>%
  summarise(
    Mean_Importance = mean(Importance, na.rm = TRUE),
    Lower95 = quantile(Importance, 0.025, na.rm = TRUE),
    Upper95 = quantile(Importance, 0.975, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Mean_Importance)) %>%
  slice(1:10)

print(importance_summary)

# ------------------------------------------------------------
# 8. Clean feature labels
# ------------------------------------------------------------

importance_summary <- importance_summary %>%
  mutate(
    Feature_Label = recode(
      Feature,
      "review_taste" = "Taste",
      "review_palate" = "Palate",
      "review_aroma" = "Aroma",
      "review_appearance" = "Appearance",
      "beer_abv" = "Alcohol by volume",
      "brewery_id" = "Brewery ID",
      "beer_beerid" = "Beer ID",
      "User_Review_Count" = "Reviewer experience",
      "n_reviews" = "Number of reviews",
      .default = Feature
    )
  )

importance_summary$Feature_Label <- factor(
  importance_summary$Feature_Label,
  levels = rev(importance_summary$Feature_Label)
)

# ------------------------------------------------------------
# 9. Create Heliyon/Q1 Figure 4
# ------------------------------------------------------------

fig4 <- ggplot(
  importance_summary,
  aes(
    x = Mean_Importance,
    y = Feature_Label
  )
) +
  geom_col(
    width = 0.65,
    fill = "#2C7FB8"
  ) +
  geom_errorbarh(
    aes(
      xmin = Lower95,
      xmax = Upper95
    ),
    height = 0.22,
    linewidth = 0.9,
    color = "#1A1A1A"
  ) +
  labs(
    title = "Figure 4. Top 10 Predictors of Beer Ratings",
    subtitle = "Random Forest variable importance with 95% bootstrap confidence intervals",
    x = "Mean variable importance",
    y = NULL
  ) +
  theme_minimal(base_size = 18) +
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 21
    ),
    plot.subtitle = element_text(
      hjust = 0.5,
      size = 15
    ),
    axis.title.x = element_text(
      face = "bold",
      size = 16
    ),
    axis.text.x = element_text(
      size = 13
    ),
    axis.text.y = element_text(
      face = "bold",
      size = 14
    ),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank()
  )

print(fig4)

# ------------------------------------------------------------
# 10. Export TIFF
# ------------------------------------------------------------

ggsave(
  filename = "Figure4_FeatureImportance_Heliyon_CI.tiff",
  plot = fig4,
  width = 9,
  height = 7,
  units = "in",
  dpi = 300,
  compression = "lzw"
)

# ------------------------------------------------------------
# 11. Save importance table
# ------------------------------------------------------------

write.csv(
  importance_summary,
  "Figure4_FeatureImportance_Top10_CI.csv",
  row.names = FALSE
)

cat("\nFigure 4 exported successfully:\n")
cat("Figure4_FeatureImportance_Heliyon_CI.tiff\n")
cat("Importance table saved as:\n")
cat("Figure4_FeatureImportance_Top10_CI.csv\n")
----------------------------------------------------------------------------------------------------------------------------------
  # ============================================================
# RECREATE SVR TUNING OBJECT AND EXTRACT BEST HYPERPARAMETERS
# Aggregated target only
# ============================================================

library(dplyr)
library(caret)
library(kernlab)
library(readxl)

set.seed(123)

# ------------------------------------------------------------
# 1. Load data if beer_data is missing
# ------------------------------------------------------------

if (!exists("beer_data")) {
  
  beer_data <- readxl::read_excel(
    "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/BEER REVIEW PREDICTION/DATASET/beer_reviews.xlsx"
  )
  
  names(beer_data) <- make.names(names(beer_data), unique = TRUE)
}

# ------------------------------------------------------------
# 2. Rebuild cleaned raw data
# ------------------------------------------------------------

beer_data <- beer_data %>%
  mutate(
    Overall_Rating = as.numeric(review_overall),
    review_taste = as.numeric(review_taste),
    review_aroma = as.numeric(review_aroma),
    review_palate = as.numeric(review_palate),
    review_appearance = as.numeric(review_appearance),
    beer_abv = as.numeric(beer_abv),
    brewery_id = as.numeric(brewery_id),
    beer_beerid = as.numeric(beer_beerid)
  ) %>%
  filter(!is.na(Overall_Rating))

beer_data <- beer_data %>%
  group_by(review_profilename) %>%
  mutate(User_Review_Count = n()) %>%
  ungroup()

# ------------------------------------------------------------
# 3. Rebuild aggregated dataset
# ------------------------------------------------------------

agg_df <- beer_data %>%
  group_by(beer_beerid, beer_name, beer_style) %>%
  summarise(
    Overall_Rating = mean(Overall_Rating, na.rm = TRUE),
    review_taste = mean(review_taste, na.rm = TRUE),
    review_aroma = mean(review_aroma, na.rm = TRUE),
    review_palate = mean(review_palate, na.rm = TRUE),
    review_appearance = mean(review_appearance, na.rm = TRUE),
    beer_abv = mean(beer_abv, na.rm = TRUE),
    brewery_id = first(brewery_id),
    User_Review_Count = mean(User_Review_Count, na.rm = TRUE),
    n_reviews = n(),
    .groups = "drop"
  ) %>%
  na.omit()

agg_model_df <- agg_df %>%
  select(
    Overall_Rating,
    review_taste,
    review_aroma,
    review_palate,
    review_appearance,
    beer_abv,
    brewery_id,
    beer_beerid,
    User_Review_Count,
    n_reviews
  ) %>%
  na.omit()

cat("Aggregated modeling rows:", nrow(agg_model_df), "\n")

# ------------------------------------------------------------
# 4. Optional sampling to prevent SVR from becoming too slow
# ------------------------------------------------------------

set.seed(123)

svr_df <- agg_model_df

if (nrow(svr_df) > 30000) {
  svr_df <- svr_df %>%
    sample_n(30000)
}

cat("SVR training rows used:", nrow(svr_df), "\n")

# ------------------------------------------------------------
# 5. Train/test split
# ------------------------------------------------------------

set.seed(123)

train_index <- createDataPartition(
  svr_df$Overall_Rating,
  p = 0.8,
  list = FALSE
)

svr_train <- svr_df[train_index, ]
svr_test  <- svr_df[-train_index, ]

# ------------------------------------------------------------
# 6. Cross-validation control
# ------------------------------------------------------------

svr_control <- trainControl(
  method = "cv",
  number = 5,
  verboseIter = TRUE
)

# ------------------------------------------------------------
# 7. Tuning grid
# ------------------------------------------------------------

svr_grid <- expand.grid(
  sigma = c(0.005, 0.01, 0.02),
  C = c(1, 5, 10)
)

# ------------------------------------------------------------
# 8. Fit tuned SVR model
# ------------------------------------------------------------

set.seed(123)

svr_tuned <- train(
  Overall_Rating ~ .,
  data = svr_train,
  method = "svmRadial",
  trControl = svr_control,
  tuneGrid = svr_grid,
  metric = "RMSE",
  preProcess = c("center", "scale")
)

# ------------------------------------------------------------
# 9. Extract and print best hyperparameters
# ------------------------------------------------------------

print(svr_tuned)
print(svr_tuned$bestTune)

best_sigma <- svr_tuned$bestTune$sigma
best_C <- svr_tuned$bestTune$C

cat("\nBest SVR hyperparameters:\n")
cat("Kernel = Radial Basis Function (RBF)\n")
cat("Sigma/Gamma =", best_sigma, "\n")
cat("Cost C =", best_C, "\n")

# ------------------------------------------------------------
# 10. Evaluate on test set
# ------------------------------------------------------------

svr_pred <- predict(
  svr_tuned,
  newdata = svr_test
)

svr_rmse <- sqrt(mean((svr_test$Overall_Rating - svr_pred)^2))
svr_mae <- mean(abs(svr_test$Overall_Rating - svr_pred))
svr_r2 <- 1 - sum((svr_test$Overall_Rating - svr_pred)^2) /
  sum((svr_test$Overall_Rating - mean(svr_test$Overall_Rating))^2)

cat("\nSVR Test Metrics:\n")
cat("MAE =", round(svr_mae, 3), "\n")
cat("RMSE =", round(svr_rmse, 3), "\n")
cat("R2 =", round(svr_r2, 3), "\n")

# ------------------------------------------------------------
# 11. Save hyperparameter table
# ------------------------------------------------------------

svr_hyperparameter_table <- data.frame(
  Model = "Support Vector Regression",
  Kernel = "Radial Basis Function (RBF)",
  Sigma_Gamma = best_sigma,
  Cost_C = best_C,
  CV_Method = "5-fold cross-validation",
  Preprocessing = "Centering and scaling"
)

write.csv(
  svr_hyperparameter_table,
  "SVR_Hyperparameter_Settings.csv",
  row.names = FALSE
)

cat("\nSaved: SVR_Hyperparameter_Settings.csv\n")

#--------------------------------------------------------------------------------------------------------------------------
# =====================================================================
# JRCS GROUPED-VALIDATION ROBUSTNESS ANALYSIS
# Syntax-safe compact version
# =====================================================================

rm(list = ls())
gc()

set.seed(123)

options(
  timeout = 600,
  repos = c(CRAN = "https://cloud.r-project.org")
)

# =====================================================================
# 1. PACKAGES
# =====================================================================

required_packages <- c(
  "readxl",
  "dplyr",
  "ggplot2",
  "ranger",
  "kernlab"
)

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(
      pkg,
      dependencies = c("Depends", "Imports", "LinkingTo")
    )
  }
  
  suppressPackageStartupMessages(
    library(pkg, character.only = TRUE)
  )
}

cat("\nPackages loaded successfully.\n")

# =====================================================================
# 2. DATASET LOCATION
# =====================================================================

dataset_dir <- "C:/Users/sahlw/OneDrive/Desktop/YNU2/PROJECT/BEER REVIEW PREDICTION/DATASET"

if (!dir.exists(dataset_dir)) {
  stop(paste("Dataset directory does not exist:", dataset_dir))
}

candidate_files <- list.files(
  dataset_dir,
  pattern = "^beer_reviews.*\\.(xlsx|xls|csv)$",
  full.names = TRUE,
  ignore.case = TRUE
)

if (length(candidate_files) == 0) {
  stop("No beer_reviews Excel or CSV file was found.")
}

preferred_names <- c(
  "beer_reviews.xlsx",
  "beer_reviews.xls",
  "beer_reviews.csv",
  "beer_reviews(1).xlsx",
  "beer_reviews(1).xls",
  "beer_reviews(1).csv"
)

candidate_names <- basename(candidate_files)
preferred_match <- match(preferred_names, candidate_names)
preferred_match <- preferred_match[!is.na(preferred_match)]

if (length(preferred_match) > 0) {
  file_path <- candidate_files[preferred_match[1]]
} else {
  file_path <- candidate_files[1]
}

cat("\nDataset selected:\n", file_path, "\n")

# =====================================================================
# 3. READ DATA
# =====================================================================

file_extension <- tolower(tools::file_ext(file_path))

if (file_extension %in% c("xlsx", "xls")) {
  
  beer <- readxl::read_excel(file_path)
  
} else if (file_extension == "csv") {
  
  beer <- read.csv(
    file_path,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  
} else {
  stop("Unsupported file type.")
}

cat(
  "\nSource data:",
  format(nrow(beer), big.mark = ","),
  "rows x",
  ncol(beer),
  "columns\n"
)

# =====================================================================
# 4. OUTPUT DIRECTORY
# =====================================================================

output_dir <- file.path(
  dataset_dir,
  "JRCS_Grouped_Validation_Results"
)

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

out_file <- function(filename) {
  file.path(output_dir, filename)
}

# =====================================================================
# 5. REQUIRED VARIABLES
# =====================================================================

required_variables <- c(
  "review_taste",
  "review_aroma",
  "review_appearance",
  "review_palate",
  "beer_abv",
  "beer_beerid",
  "review_profilename"
)

missing_variables <- setdiff(
  required_variables,
  names(beer)
)

if (length(missing_variables) > 0) {
  stop(
    paste(
      "Missing required variables:",
      paste(missing_variables, collapse = ", ")
    )
  )
}

# =====================================================================
# 6. CLEAN DATA
# =====================================================================

numeric_variables <- c(
  "review_taste",
  "review_aroma",
  "review_appearance",
  "review_palate",
  "beer_abv"
)

for (v in numeric_variables) {
  beer[[v]] <- suppressWarnings(as.numeric(beer[[v]]))
}

beer_clean <- beer %>%
  dplyr::select(dplyr::all_of(required_variables)) %>%
  dplyr::filter(
    !is.na(review_taste),
    is.finite(review_taste),
    !is.na(review_aroma),
    is.finite(review_aroma),
    !is.na(review_appearance),
    is.finite(review_appearance),
    !is.na(review_palate),
    is.finite(review_palate),
    !is.na(beer_beerid),
    !is.na(review_profilename)
  ) %>%
  dplyr::mutate(
    beer_beerid = as.character(beer_beerid),
    review_profilename = as.character(review_profilename)
  )

cat(
  "\nEligible observations:",
  format(nrow(beer_clean), big.mark = ","),
  "\n"
)

# =====================================================================
# 7. REPRODUCIBLE ANALYTICAL SAMPLE
# =====================================================================

analysis_n <- 5456

if (nrow(beer_clean) < analysis_n) {
  stop("Fewer than 5,456 eligible observations are available.")
}

set.seed(123)

analysis_data <- beer_clean %>%
  dplyr::slice_sample(n = analysis_n)

cat("\nAnalytical sample:", nrow(analysis_data), "\n")
cat("Unique beers:", dplyr::n_distinct(analysis_data$beer_beerid), "\n")
cat(
  "Unique reviewers:",
  dplyr::n_distinct(analysis_data$review_profilename),
  "\n"
)

write.csv(
  analysis_data,
  out_file("Analytical_Sample_5456.csv"),
  row.names = FALSE
)

# =====================================================================
# 8. MODEL SPECIFICATION
# =====================================================================

predictors <- c(
  "review_aroma",
  "review_appearance",
  "review_palate",
  "beer_abv"
)

model_formula <- review_taste ~
  review_aroma +
  review_appearance +
  review_palate +
  beer_abv

RF_MTRY <- 1
RF_MIN_NODE_SIZE <- 10
RF_NUM_TREES <- 500

SVR_SIGMA <- 0.01
SVR_C <- 1

# =====================================================================
# 9. PERFORMANCE METRICS
# =====================================================================

calculate_metrics <- function(observed, predicted) {
  
  valid <- is.finite(observed) & is.finite(predicted)
  
  observed <- observed[valid]
  predicted <- predicted[valid]
  
  mae <- mean(abs(observed - predicted))
  
  rmse <- sqrt(
    mean((observed - predicted)^2)
  )
  
  sse <- sum((observed - predicted)^2)
  sst <- sum((observed - mean(observed))^2)
  
  r2 <- ifelse(
    sst > 0,
    1 - (sse / sst),
    NA_real_
  )
  
  data.frame(
    MAE = mae,
    RMSE = rmse,
    R2 = r2
  )
}

# =====================================================================
# 10. MEDIAN IMPUTATION
# =====================================================================

calculate_medians <- function(training_data) {
  
  medians <- sapply(
    training_data[predictors],
    median,
    na.rm = TRUE
  )
  
  if (any(!is.finite(medians))) {
    stop("At least one predictor median could not be calculated.")
  }
  
  medians
}

apply_medians <- function(data, medians) {
  
  for (v in predictors) {
    
    bad <- is.na(data[[v]]) | !is.finite(data[[v]])
    
    if (any(bad)) {
      data[[v]][bad] <- medians[[v]]
    }
  }
  
  data
}

# =====================================================================
# 11. EXTERNAL SPLIT FUNCTION
# =====================================================================

create_split <- function(
    data,
    scheme,
    development_prop = 0.80,
    seed = 123
) {
  
  set.seed(seed)
  
  if (scheme == "Review-level") {
    
    n_dev <- floor(development_prop * nrow(data))
    
    dev_index <- sample(
      seq_len(nrow(data)),
      size = n_dev,
      replace = FALSE
    )
    
    development <- data[dev_index, , drop = FALSE]
    test <- data[-dev_index, , drop = FALSE]
    
  } else if (scheme == "Beer-disjoint") {
    
    groups <- unique(data$beer_beerid)
    
    n_dev_groups <- floor(
      development_prop * length(groups)
    )
    
    dev_groups <- sample(
      groups,
      size = n_dev_groups,
      replace = FALSE
    )
    
    development <- data[
      data$beer_beerid %in% dev_groups,
      ,
      drop = FALSE
    ]
    
    test <- data[
      !(data$beer_beerid %in% dev_groups),
      ,
      drop = FALSE
    ]
    
  } else if (scheme == "Reviewer-disjoint") {
    
    groups <- unique(data$review_profilename)
    
    n_dev_groups <- floor(
      development_prop * length(groups)
    )
    
    dev_groups <- sample(
      groups,
      size = n_dev_groups,
      replace = FALSE
    )
    
    development <- data[
      data$review_profilename %in% dev_groups,
      ,
      drop = FALSE
    ]
    
    test <- data[
      !(data$review_profilename %in% dev_groups),
      ,
      drop = FALSE
    ]
    
  } else {
    
    stop(paste("Unknown validation scheme:", scheme))
  }
  
  if (nrow(development) == 0 || nrow(test) == 0) {
    stop(paste("Empty development or test set for:", scheme))
  }
  
  list(
    development = development,
    test = test
  )
}

# =====================================================================
# 12. SPLIT LEAKAGE CHECK
# =====================================================================

check_overlap <- function(development, test) {
  
  beer_overlap <- length(
    intersect(
      unique(development$beer_beerid),
      unique(test$beer_beerid)
    )
  )
  
  reviewer_overlap <- length(
    intersect(
      unique(development$review_profilename),
      unique(test$review_profilename)
    )
  )
  
  list(
    Beer_Overlap = beer_overlap,
    Reviewer_Overlap = reviewer_overlap
  )
}

# =====================================================================
# 13. CV FOLD ASSIGNMENT
# =====================================================================

create_cv_folds <- function(
    data,
    scheme,
    k = 5,
    seed = 456
) {
  
  set.seed(seed)
  
  if (scheme == "Review-level") {
    
    shuffled_rows <- sample(seq_len(nrow(data)))
    
    fold_seq <- rep(
      seq_len(k),
      length.out = nrow(data)
    )
    
    fold_assignment <- integer(nrow(data))
    
    fold_assignment[shuffled_rows] <- fold_seq
    
  } else {
    
    if (scheme == "Beer-disjoint") {
      group_vector <- data$beer_beerid
    } else if (scheme == "Reviewer-disjoint") {
      group_vector <- data$review_profilename
    } else {
      stop("Unknown CV scheme.")
    }
    
    unique_groups <- sample(
      unique(group_vector)
    )
    
    group_folds <- rep(
      seq_len(k),
      length.out = length(unique_groups)
    )
    
    fold_lookup <- setNames(
      group_folds,
      unique_groups
    )
    
    fold_assignment <- as.integer(
      fold_lookup[group_vector]
    )
  }
  
  fold_assignment
}

# =====================================================================
# 14. MODEL FITTING FUNCTIONS
# =====================================================================

fit_lm_model <- function(training_data) {
  
  lm(
    model_formula,
    data = training_data
  )
}

fit_rf_model <- function(
    training_data,
    trees = RF_NUM_TREES
) {
  
  ranger::ranger(
    formula = model_formula,
    data = training_data,
    num.trees = trees,
    mtry = RF_MTRY,
    min.node.size = RF_MIN_NODE_SIZE,
    splitrule = "variance",
    importance = "permutation",
    seed = 123,
    num.threads = max(
      1,
      parallel::detectCores() - 1
    )
  )
}

fit_svr_model <- function(training_data) {
  
  x_train <- as.matrix(
    training_data[predictors]
  )
  
  y_train <- training_data$review_taste
  
  kernlab::ksvm(
    x = x_train,
    y = y_train,
    type = "eps-svr",
    kernel = kernlab::rbfdot(
      sigma = SVR_SIGMA
    ),
    C = SVR_C,
    scaled = TRUE
  )
}

# =====================================================================
# 15. CROSS-VALIDATED ENSEMBLE WEIGHTS
# =====================================================================

estimate_cv_weights <- function(
    development_data,
    scheme,
    k = 5
) {
  
  fold_assignment <- create_cv_folds(
    data = development_data,
    scheme = scheme,
    k = k,
    seed = 456
  )
  
  rf_predictions <- rep(
    NA_real_,
    nrow(development_data)
  )
  
  svr_predictions <- rep(
    NA_real_,
    nrow(development_data)
  )
  
  for (fold in seq_len(k)) {
    
    cat(
      "  CV fold",
      fold,
      "of",
      k,
      "\n"
    )
    
    training_fold <- development_data[
      fold_assignment != fold,
      ,
      drop = FALSE
    ]
    
    validation_fold <- development_data[
      fold_assignment == fold,
      ,
      drop = FALSE
    ]
    
    fold_medians <- calculate_medians(
      training_fold
    )
    
    training_fold <- apply_medians(
      training_fold,
      fold_medians
    )
    
    validation_fold <- apply_medians(
      validation_fold,
      fold_medians
    )
    
    rf_fold <- fit_rf_model(
      training_fold,
      trees = 300
    )
    
    rf_predictions[
      fold_assignment == fold
    ] <- predict(
      rf_fold,
      data = validation_fold
    )$predictions
    
    svr_fold <- fit_svr_model(
      training_fold
    )
    
    x_validation <- as.matrix(
      validation_fold[predictors]
    )
    
    svr_predictions[
      fold_assignment == fold
    ] <- as.numeric(
      predict(
        svr_fold,
        x_validation
      )
    )
  }
  
  rf_rmse <- calculate_metrics(
    development_data$review_taste,
    rf_predictions
  )$RMSE
  
  svr_rmse <- calculate_metrics(
    development_data$review_taste,
    svr_predictions
  )$RMSE
  
  inv_rf <- 1 / rf_rmse
  inv_svr <- 1 / svr_rmse
  
  rf_weight <- inv_rf / (inv_rf + inv_svr)
  svr_weight <- inv_svr / (inv_rf + inv_svr)
  
  list(
    RF_CV_RMSE = rf_rmse,
    SVR_CV_RMSE = svr_rmse,
    RF_Weight = rf_weight,
    SVR_Weight = svr_weight
  )
}

# =====================================================================
# 16. BOOTSTRAP CI FUNCTION
# =====================================================================

bootstrap_metrics <- function(
    observed,
    predicted,
    groups = NULL,
    B = 1000,
    seed = 789
) {
  
  set.seed(seed)
  
  boot_mae <- numeric(B)
  boot_rmse <- numeric(B)
  boot_r2 <- numeric(B)
  
  for (b in seq_len(B)) {
    
    if (is.null(groups)) {
      
      index <- sample(
        seq_along(observed),
        size = length(observed),
        replace = TRUE
      )
      
    } else {
      
      unique_groups <- unique(groups)
      
      sampled_groups <- sample(
        unique_groups,
        size = length(unique_groups),
        replace = TRUE
      )
      
      index <- unlist(
        lapply(
          sampled_groups,
          function(g) {
            which(groups == g)
          }
        ),
        use.names = FALSE
      )
    }
    
    m <- calculate_metrics(
      observed[index],
      predicted[index]
    )
    
    boot_mae[b] <- m$MAE
    boot_rmse[b] <- m$RMSE
    boot_r2[b] <- m$R2
  }
  
  data.frame(
    Metric = c("MAE", "RMSE", "R2"),
    CI_Lower = c(
      quantile(boot_mae, 0.025, na.rm = TRUE),
      quantile(boot_rmse, 0.025, na.rm = TRUE),
      quantile(boot_r2, 0.025, na.rm = TRUE)
    ),
    CI_Upper = c(
      quantile(boot_mae, 0.975, na.rm = TRUE),
      quantile(boot_rmse, 0.975, na.rm = TRUE),
      quantile(boot_r2, 0.975, na.rm = TRUE)
    )
  )
}

# =====================================================================
# 17. RUN ONE VALIDATION REGIME
# =====================================================================

run_validation_scheme <- function(
    data,
    scheme,
    split_seed = 123
) {
  
  cat(
    "\n============================================================\n"
  )
  
  cat(
    "VALIDATION REGIME:",
    scheme,
    "\n"
  )
  
  cat(
    "============================================================\n"
  )
  
  split_result <- create_split(
    data = data,
    scheme = scheme,
    development_prop = 0.80,
    seed = split_seed
  )
  
  development <- split_result$development
  test <- split_result$test
  
  overlaps <- check_overlap(
    development,
    test
  )
  
  if (
    scheme == "Beer-disjoint" &&
    overlaps$Beer_Overlap != 0
  ) {
    stop("Beer leakage detected.")
  }
  
  if (
    scheme == "Reviewer-disjoint" &&
    overlaps$Reviewer_Overlap != 0
  ) {
    stop("Reviewer leakage detected.")
  }
  
  cat(
    "Development reviews:",
    nrow(development),
    "\n"
  )
  
  cat(
    "Test reviews:",
    nrow(test),
    "\n"
  )
  
  cat(
    "Beer overlap:",
    overlaps$Beer_Overlap,
    "\n"
  )
  
  cat(
    "Reviewer overlap:",
    overlaps$Reviewer_Overlap,
    "\n"
  )
  
  # ---------------------------------------------------------------
  # CROSS-VALIDATED ENSEMBLE WEIGHTS
  # ---------------------------------------------------------------
  
  cat(
    "\nEstimating ensemble weights...\n"
  )
  
  cv_weights <- estimate_cv_weights(
    development_data = development,
    scheme = scheme,
    k = 5
  )
  
  # ---------------------------------------------------------------
  # DEVELOPMENT-ONLY IMPUTATION
  # ---------------------------------------------------------------
  
  development_medians <- calculate_medians(
    development
  )
  
  development <- apply_medians(
    development,
    development_medians
  )
  
  test <- apply_medians(
    test,
    development_medians
  )
  
  # ---------------------------------------------------------------
  # FINAL MODELS
  # ---------------------------------------------------------------
  
  cat("Fitting Linear Regression...\n")
  
  lm_model <- fit_lm_model(
    development
  )
  
  cat("Fitting Random Forest...\n")
  
  rf_model <- fit_rf_model(
    development
  )
  
  cat("Fitting SVR...\n")
  
  svr_model <- fit_svr_model(
    development
  )
  
  # ---------------------------------------------------------------
  # PREDICTIONS
  # ---------------------------------------------------------------
  
  pred_lm <- as.numeric(
    predict(
      lm_model,
      newdata = test
    )
  )
  
  pred_rf <- as.numeric(
    predict(
      rf_model,
      data = test
    )$predictions
  )
  
  x_test <- as.matrix(
    test[predictors]
  )
  
  pred_svr <- as.numeric(
    predict(
      svr_model,
      x_test
    )
  )
  
  pred_ensemble <- (
    cv_weights$RF_Weight * pred_rf
  ) + (
    cv_weights$SVR_Weight * pred_svr
  )
  
  # ---------------------------------------------------------------
  # PERFORMANCE ROW FUNCTION
  # ---------------------------------------------------------------
  
  make_row <- function(
    model_name,
    predictions
  ) {
    
    m <- calculate_metrics(
      test$review_taste,
      predictions
    )
    
    data.frame(
      Validation_Scheme = scheme,
      Model = model_name,
      MAE = m$MAE,
      RMSE = m$RMSE,
      R2 = m$R2
    )
  }
  
  performance <- dplyr::bind_rows(
    make_row(
      "Linear Regression",
      pred_lm
    ),
    make_row(
      "Random Forest",
      pred_rf
    ),
    make_row(
      "Support Vector Regression",
      pred_svr
    ),
    make_row(
      "Weighted RF-SVR Ensemble",
      pred_ensemble
    )
  )
  
  # ---------------------------------------------------------------
  # GROUP-AWARE BOOTSTRAP
  # ---------------------------------------------------------------
  
  if (scheme == "Beer-disjoint") {
    
    bootstrap_groups <- test$beer_beerid
    
  } else if (
    scheme == "Reviewer-disjoint"
  ) {
    
    bootstrap_groups <- test$review_profilename
    
  } else {
    
    bootstrap_groups <- NULL
  }
  
  ensemble_ci <- bootstrap_metrics(
    observed = test$review_taste,
    predicted = pred_ensemble,
    groups = bootstrap_groups,
    B = 1000,
    seed = 789
  )
  
  ensemble_metrics <- calculate_metrics(
    test$review_taste,
    pred_ensemble
  )
  
  ensemble_ci$Estimate <- c(
    ensemble_metrics$MAE,
    ensemble_metrics$RMSE,
    ensemble_metrics$R2
  )
  
  ensemble_ci$Validation_Scheme <- scheme
  ensemble_ci$Model <- "Weighted RF-SVR Ensemble"
  
  ensemble_ci <- ensemble_ci %>%
    dplyr::select(
      Validation_Scheme,
      Model,
      Metric,
      Estimate,
      CI_Lower,
      CI_Upper
    )
  
  # ---------------------------------------------------------------
  # PREDICTIONS TABLE
  # ---------------------------------------------------------------
  
  predictions <- data.frame(
    Validation_Scheme = scheme,
    beer_beerid = test$beer_beerid,
    review_profilename = test$review_profilename,
    Observed_Taste = test$review_taste,
    Linear_Regression = pred_lm,
    Random_Forest = pred_rf,
    SVR = pred_svr,
    Weighted_Ensemble = pred_ensemble
  )
  
  # ---------------------------------------------------------------
  # SPLIT SUMMARY
  # ---------------------------------------------------------------
  
  split_summary <- data.frame(
    Validation_Scheme = scheme,
    Development_Reviews = nrow(development),
    Test_Reviews = nrow(test),
    Development_Beers =
      dplyr::n_distinct(development$beer_beerid),
    Test_Beers =
      dplyr::n_distinct(test$beer_beerid),
    Development_Reviewers =
      dplyr::n_distinct(development$review_profilename),
    Test_Reviewers =
      dplyr::n_distinct(test$review_profilename),
    Beer_Overlap = overlaps$Beer_Overlap,
    Reviewer_Overlap = overlaps$Reviewer_Overlap
  )
  
  # ---------------------------------------------------------------
  # WEIGHT SUMMARY
  # ---------------------------------------------------------------
  
  weight_summary <- data.frame(
    Validation_Scheme = scheme,
    RF_CV_RMSE = cv_weights$RF_CV_RMSE,
    SVR_CV_RMSE = cv_weights$SVR_CV_RMSE,
    RF_Weight = cv_weights$RF_Weight,
    SVR_Weight = cv_weights$SVR_Weight
  )
  
  list(
    Performance = performance,
    Confidence_Intervals = ensemble_ci,
    Predictions = predictions,
    Split_Summary = split_summary,
    Weights = weight_summary
  )
}

# =====================================================================
# 18. RUN ALL THREE VALIDATION REGIMES
# =====================================================================

validation_schemes <- c(
  "Review-level",
  "Beer-disjoint",
  "Reviewer-disjoint"
)

all_results <- list()

for (scheme_name in validation_schemes) {
  
  all_results[[scheme_name]] <- run_validation_scheme(
    data = analysis_data,
    scheme = scheme_name,
    split_seed = 123
  )
}

# =====================================================================
# 19. COMBINE PERFORMANCE TABLE
# =====================================================================

performance_table <- dplyr::bind_rows(
  lapply(
    all_results,
    function(x) x$Performance
  )
)

performance_table <- performance_table %>%
  dplyr::mutate(
    Validation_Scheme = factor(
      Validation_Scheme,
      levels = validation_schemes
    )
  ) %>%
  dplyr::arrange(
    Validation_Scheme,
    RMSE
  )

print(performance_table)

write.csv(
  performance_table,
  out_file(
    "Table1_Grouped_Validation_Performance.csv"
  ),
  row.names = FALSE
)

# =====================================================================
# 20. COMBINE SPLIT SUMMARY
# =====================================================================

split_summary <- dplyr::bind_rows(
  lapply(
    all_results,
    function(x) x$Split_Summary
  )
)

print(split_summary)

write.csv(
  split_summary,
  out_file(
    "Table2_Validation_Split_Summary.csv"
  ),
  row.names = FALSE
)

# =====================================================================
# 21. COMBINE ENSEMBLE WEIGHTS
# =====================================================================

weight_table <- dplyr::bind_rows(
  lapply(
    all_results,
    function(x) x$Weights
  )
)

print(weight_table)

write.csv(
  weight_table,
  out_file(
    "Table3_Grouped_Validation_Ensemble_Weights.csv"
  ),
  row.names = FALSE
)

# =====================================================================
# 22. COMBINE BOOTSTRAP CIs
# =====================================================================

confidence_interval_table <- dplyr::bind_rows(
  lapply(
    all_results,
    function(x) x$Confidence_Intervals
  )
)

print(confidence_interval_table)

write.csv(
  confidence_interval_table,
  out_file(
    "Table4_Ensemble_Bootstrap_Confidence_Intervals.csv"
  ),
  row.names = FALSE
)

# =====================================================================
# 23. PERFORMANCE CHANGE VS REVIEW-LEVEL BASELINE
# =====================================================================

review_baseline <- performance_table %>%
  dplyr::filter(
    Validation_Scheme == "Review-level"
  ) %>%
  dplyr::select(
    Model,
    Baseline_MAE = MAE,
    Baseline_RMSE = RMSE,
    Baseline_R2 = R2
  )

degradation_table <- performance_table %>%
  dplyr::left_join(
    review_baseline,
    by = "Model"
  ) %>%
  dplyr::mutate(
    MAE_Absolute_Change =
      MAE - Baseline_MAE,
    
    RMSE_Absolute_Change =
      RMSE - Baseline_RMSE,
    
    R2_Absolute_Change =
      R2 - Baseline_R2,
    
    MAE_Percent_Change =
      100 *
      (MAE - Baseline_MAE) /
      Baseline_MAE,
    
    RMSE_Percent_Change =
      100 *
      (RMSE - Baseline_RMSE) /
      Baseline_RMSE
  )

print(degradation_table)

write.csv(
  degradation_table,
  out_file(
    "Table5_Performance_Change_vs_Review_Level.csv"
  ),
  row.names = FALSE
)

# =====================================================================
# 24. MANUSCRIPT-READY PERFORMANCE TABLE
# =====================================================================

manuscript_table <- performance_table %>%
  dplyr::mutate(
    MAE = round(MAE, 4),
    RMSE = round(RMSE, 4),
    R2 = round(R2, 4)
  )

write.csv(
  manuscript_table,
  out_file(
    "Table6_Manuscript_Ready_Grouped_Validation.csv"
  ),
  row.names = FALSE
)

print(manuscript_table)

# =====================================================================
# 25. BEST MODEL BY VALIDATION REGIME
# =====================================================================

best_by_scheme <- performance_table %>%
  dplyr::group_by(
    Validation_Scheme
  ) %>%
  dplyr::slice_min(
    order_by = RMSE,
    n = 1,
    with_ties = FALSE
  ) %>%
  dplyr::ungroup()

print(best_by_scheme)

write.csv(
  best_by_scheme,
  out_file(
    "Table7_Best_Model_By_Validation_Regime.csv"
  ),
  row.names = FALSE
)

# =====================================================================
# 26. EXPORT PREDICTIONS
# =====================================================================

for (scheme_name in validation_schemes) {
  
  safe_name <- gsub(
    "-",
    "_",
    scheme_name
  )
  
  safe_name <- gsub(
    " ",
    "_",
    safe_name
  )
  
  write.csv(
    all_results[[scheme_name]]$Predictions,
    out_file(
      paste0(
        "Predictions_",
        safe_name,
        ".csv"
      )
    ),
    row.names = FALSE
  )
}

# =====================================================================
# 27. FIGURE 1: RMSE COMPARISON
# =====================================================================

figure1 <- ggplot2::ggplot(
  performance_table,
  ggplot2::aes(
    x = Validation_Scheme,
    y = RMSE,
    group = Model,
    shape = Model,
    linetype = Model
  )
) +
  ggplot2::geom_line(
    linewidth = 0.8
  ) +
  ggplot2::geom_point(
    size = 3
  ) +
  ggplot2::labs(
    title =
      "Predictive Error Across Validation Regimes",
    subtitle =
      "Review-level, beer-disjoint and reviewer-disjoint validation",
    x =
      "Validation regime",
    y =
      "RMSE"
  ) +
  ggplot2::theme_minimal(
    base_size = 12
  ) +
  ggplot2::theme(
    axis.text.x =
      ggplot2::element_text(
        angle = 15,
        hjust = 1
      ),
    legend.position =
      "bottom"
  )

ggplot2::ggsave(
  filename =
    out_file(
      "Figure1_RMSE_Across_Validation_Regimes.tiff"
    ),
  plot = figure1,
  width = 8,
  height = 5.5,
  dpi = 600,
  compression = "lzw"
)

# =====================================================================
# 28. FIGURE 2: R2 COMPARISON
# =====================================================================

figure2 <- ggplot2::ggplot(
  performance_table,
  ggplot2::aes(
    x = Validation_Scheme,
    y = R2,
    group = Model,
    shape = Model,
    linetype = Model
  )
) +
  ggplot2::geom_line(
    linewidth = 0.8
  ) +
  ggplot2::geom_point(
    size = 3
  ) +
  ggplot2::labs(
    title =
      "Explained Variance Across Validation Regimes",
    subtitle =
      "Generalization to unseen beers and unseen reviewers",
    x =
      "Validation regime",
    y =
      expression(R^2)
  ) +
  ggplot2::theme_minimal(
    base_size = 12
  ) +
  ggplot2::theme(
    axis.text.x =
      ggplot2::element_text(
        angle = 15,
        hjust = 1
      ),
    legend.position =
      "bottom"
  )

ggplot2::ggsave(
  filename =
    out_file(
      "Figure2_R2_Across_Validation_Regimes.tiff"
    ),
  plot = figure2,
  width = 8,
  height = 5.5,
  dpi = 600,
  compression = "lzw"
)

# =====================================================================
# 29. FIGURE 3: BEST MODEL RMSE
# =====================================================================

figure3 <- ggplot2::ggplot(
  best_by_scheme,
  ggplot2::aes(
    x = Validation_Scheme,
    y = RMSE
  )
) +
  ggplot2::geom_col(
    width = 0.65
  ) +
  ggplot2::geom_text(
    ggplot2::aes(
      label = sprintf("%.4f", RMSE)
    ),
    vjust = -0.5,
    size = 4
  ) +
  ggplot2::labs(
    title =
      "Best Predictive Performance Under Alternative Validation Regimes",
    x =
      "Validation regime",
    y =
      "RMSE"
  ) +
  ggplot2::theme_minimal(
    base_size = 12
  )

ggplot2::ggsave(
  filename =
    out_file(
      "Figure3_Best_Model_RMSE_Comparison.tiff"
    ),
  plot = figure3,
  width = 7,
  height = 5,
  dpi = 600,
  compression = "lzw"
)

# =====================================================================
# 30. REPRODUCIBILITY RECORD
# =====================================================================

sink(
  out_file(
    "Reproducibility_Record_JRCS_Grouped_Validation.txt"
  )
)

cat(
  "JRCS GROUPED-VALIDATION ROBUSTNESS ANALYSIS\n"
)

cat(
  "============================================================\n\n"
)

cat(
  "Dataset file:",
  file_path,
  "\n"
)

cat(
  "Original source observations:",
  nrow(beer),
  "\n"
)

cat(
  "Eligible observations:",
  nrow(beer_clean),
  "\n"
)

cat(
  "Analytical sample:",
  nrow(analysis_data),
  "\n"
)

cat(
  "Unique beers:",
  dplyr::n_distinct(
    analysis_data$beer_beerid
  ),
  "\n"
)

cat(
  "Unique reviewers:",
  dplyr::n_distinct(
    analysis_data$review_profilename
  ),
  "\n\n"
)

cat(
  "Primary seed: 123\n"
)

cat(
  "CV seed: 456\n"
)

cat(
  "Bootstrap seed: 789\n\n"
)

cat(
  "TARGET:\nreview_taste\n\n"
)

cat(
  "PREDICTORS:\n"
)

cat(
  paste(
    predictors,
    collapse = ", "
  ),
  "\n\n"
)

cat(
  "VALIDATION REGIMES:\n"
)

cat(
  "1. Review-level random split\n"
)

cat(
  "2. Beer-disjoint split\n"
)

cat(
  "3. Reviewer-disjoint split\n\n"
)

cat(
  "RANDOM FOREST:\n"
)

cat(
  "num.trees =",
  RF_NUM_TREES,
  "\n"
)

cat(
  "mtry =",
  RF_MTRY,
  "\n"
)

cat(
  "min.node.size =",
  RF_MIN_NODE_SIZE,
  "\n"
)

cat(
  "splitrule = variance\n\n"
)

cat(
  "SVR:\n"
)

cat(
  "sigma =",
  SVR_SIGMA,
  "\n"
)

cat(
  "C =",
  SVR_C,
  "\n\n"
)

cat(
  "PERFORMANCE TABLE\n"
)

print(
  performance_table
)

cat(
  "\nSPLIT SUMMARY\n"
)

print(
  split_summary
)

cat(
  "\nENSEMBLE WEIGHTS\n"
)

print(
  weight_table
)

cat(
  "\nBOOTSTRAP CONFIDENCE INTERVALS\n"
)

print(
  confidence_interval_table
)

cat(
  "\nPERFORMANCE CHANGE VS REVIEW-LEVEL\n"
)

print(
  degradation_table
)

cat(
  "\nBEST MODEL BY VALIDATION REGIME\n"
)

print(
  best_by_scheme
)

cat(
  "\nSESSION INFORMATION\n"
)

print(
  sessionInfo()
)

sink()

# =====================================================================
# 31. OUTPUT CHECK
# =====================================================================

expected_outputs <- c(
  "Analytical_Sample_5456.csv",
  "Table1_Grouped_Validation_Performance.csv",
  "Table2_Validation_Split_Summary.csv",
  "Table3_Grouped_Validation_Ensemble_Weights.csv",
  "Table4_Ensemble_Bootstrap_Confidence_Intervals.csv",
  "Table5_Performance_Change_vs_Review_Level.csv",
  "Table6_Manuscript_Ready_Grouped_Validation.csv",
  "Table7_Best_Model_By_Validation_Regime.csv",
  "Predictions_Review_level.csv",
  "Predictions_Beer_disjoint.csv",
  "Predictions_Reviewer_disjoint.csv",
  "Figure1_RMSE_Across_Validation_Regimes.tiff",
  "Figure2_R2_Across_Validation_Regimes.tiff",
  "Figure3_Best_Model_RMSE_Comparison.tiff",
  "Reproducibility_Record_JRCS_Grouped_Validation.txt"
)

output_check <- data.frame(
  File = expected_outputs,
  Exists = file.exists(
    file.path(
      output_dir,
      expected_outputs
    )
  )
)

write.csv(
  output_check,
  out_file(
    "Output_File_Check.csv"
  ),
  row.names = FALSE
)

print(
  output_check
)

# =====================================================================
# 32. FINAL SUMMARY
# =====================================================================

cat(
  "\n============================================================\n"
)

cat(
  "JRCS GROUPED-VALIDATION ANALYSIS COMPLETED\n"
)

cat(
  "============================================================\n\n"
)

cat(
  "Results saved to:\n",
  normalizePath(
    output_dir,
    mustWork = FALSE
  ),
  "\n\n"
)

cat(
  "FINAL PERFORMANCE RESULTS:\n\n"
)

print(
  manuscript_table
)

cat(
  "\nBEST MODEL BY VALIDATION REGIME:\n\n"
)

print(
  best_by_scheme
)

cat(
  "\nLEAKAGE CHECK:\n\n"
)

print(
  split_summary
)

cat(
  "\nEND OF ANALYSIS\n"
)